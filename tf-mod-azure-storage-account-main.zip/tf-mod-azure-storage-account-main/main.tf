locals {
  # New Relic storage-log opt-in tags. The central "forward Storage Account logs to New Relic"
  # governance policy reads these per-account tags and deploys the Event Hub diagnostic setting,
  # running as the policy remediation identity that holds the cross-subscription Event Hub access.
  # The module only stamps the tags - it never creates the diagnostic setting - so no Event Hub
  # permissions are required here. Only enabled categories are tagged; absence means "do not forward".
  newrelic_storage_log_tags = merge(
    var.newrelic_storage_logs.read ? { "logs_nr_sa_read" = "true" } : {},
    var.newrelic_storage_logs.write ? { "logs_nr_sa_write" = "true" } : {},
    var.newrelic_storage_logs.delete ? { "logs_nr_sa_delete" = "true" } : {},
  )
}

resource "azurerm_storage_account" "sa" {
  name = var.name

  resource_group_name = var.resource_group_name
  location            = var.location

  account_kind             = var.account_kind
  account_tier             = var.account_tier
  account_replication_type = var.account_replication_type

  shared_access_key_enabled = var.shared_access_key_enabled
  allowed_copy_scope        = var.allowed_copy_scope

  allow_nested_items_to_be_public = var.allow_nested_items_to_be_public

  https_traffic_only_enabled = var.enable_https_traffic_only

  default_to_oauth_authentication = var.default_to_oauth_authentication

  tags = merge(var.tags, local.newrelic_storage_log_tags)

  dynamic "sas_policy" {
    for_each = var.sas_policy_expiration_period != null ? [1] : []

    content {
      expiration_period = var.sas_policy_expiration_period
    }
  }

  is_hns_enabled = var.hierarchical_namespace_enabled
  sftp_enabled   = var.sftp_enabled

  blob_properties {
    versioning_enabled            = var.blob_properties.versioning_enabled
    change_feed_enabled           = var.blob_properties.change_feed_enabled
    change_feed_retention_in_days = var.blob_properties.change_feed_retention_in_days
    last_access_time_enabled      = var.blob_properties.last_access_time_enabled
  }
}

resource "azurerm_storage_account_static_website" "web" {
  count = var.static_website.enabled ? 1 : 0

  storage_account_id = azurerm_storage_account.sa.id
  index_document     = var.static_website.index_document
  error_404_document = var.static_website.error_404_document
}

resource "azurerm_storage_container" "containers" {
  for_each = var.containers

  name               = each.key
  storage_account_id = azurerm_storage_account.sa.id
}

moved {
  from = azurerm_storage_account_network_rules.network_rules
  to   = azurerm_storage_account_network_rules.network_rules[0]
}

resource "azurerm_storage_account_network_rules" "network_rules" {
  count = var.do_not_manage_public_access ? 0 : 1

  storage_account_id = azurerm_storage_account.sa.id

  # Set default action to deny when ip_rules or virtual_network_subnet_ids are not empty
  default_action = (
    var.public_access.enabled &&
    (length(var.public_access.ip_rules) == 0 && length(var.public_access.virtual_network_subnet_ids) == 0) ?
    "Allow" :
    "Deny"
  )

  ip_rules                   = var.public_access.ip_rules
  virtual_network_subnet_ids = var.public_access.virtual_network_subnet_ids
  bypass                     = var.public_access.bypass
}
