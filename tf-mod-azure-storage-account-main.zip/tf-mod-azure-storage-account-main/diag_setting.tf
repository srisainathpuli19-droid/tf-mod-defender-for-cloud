locals {
  storage_services = toset([
    "blobServices/default",
    "queueServices/default",
    "tableServices/default",
    "fileServices/default"
  ])
}

resource "azurerm_monitor_diagnostic_setting" "diag_settings" {
  for_each = var.diagnostic_settings.enabled ? local.storage_services : []

  name                       = "send-to-log-analytics"
  target_resource_id         = "${azurerm_storage_account.sa.id}/${each.value}"
  log_analytics_workspace_id = var.diagnostic_settings.log_analytics_workspace_id

  enabled_log {
    category_group = "audit"
  }
}
