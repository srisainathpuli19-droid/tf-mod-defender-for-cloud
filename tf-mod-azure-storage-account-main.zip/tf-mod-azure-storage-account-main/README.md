# Storage account module

Terraform module for provisioning an Azure Storage Account with support for private endpoints, network access control, diagnostic settings, static website hosting, SFTP, hierarchical namespace (Data Lake Gen2), blob versioning, and storage containers.

## Requirements

- Terraform `>= 1.0`
- `azurerm` provider `~> 4.0`

## Usage

### Minimal — private storage account

```hcl
module "storage" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-storage-account.git?ref=<version>"

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "westeurope"
}
```

By default, public network access is **disabled**. The network rules default action is `Deny`.

### With public access

```hcl
module "storage" {
  source = "..."

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "westeurope"

  public_access = {
    enabled  = true
    ip_rules = ["203.0.113.0/24"]
    bypass   = ["AzureServices"]
  }
}
```

When `ip_rules` or `virtual_network_subnet_ids` are provided alongside `enabled = true`, the default action is still `Deny` — only the specified sources are allowed.

When `enabled = true` with no `ip_rules` or `virtual_network_subnet_ids`, the default action is `Allow` (open to all).

### With private endpoints

```hcl
module "storage" {
  source = "..."

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "westeurope"

  private_access = {
    enabled   = true
    subnet_id = "/subscriptions/.../subnets/my-subnet"
    subresources = {
      blob = {
        private_dns_zone_id = "/subscriptions/.../privateDnsZones/privatelink.blob.core.windows.net"
      }
      file = {}
    }
  }
}
```

One `azurerm_private_endpoint` is created per entry in `subresources`. The `private_dns_zone_group` is intentionally ignored in the lifecycle because it is managed by Azure Policy.

### With diagnostic settings

```hcl
module "storage" {
  source = "..."

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "westeurope"

  diagnostic_settings = {
    enabled                    = true
    log_analytics_workspace_id = "/subscriptions/.../workspaces/my-workspace"
  }
}
```

Audit logs are sent to Log Analytics for all four services: blob, queue, table, and file.

### Forward data-plane logs to New Relic (per category)

```hcl
module "storage" {
  source = "..."

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "swedencentral"

  newrelic_storage_logs = {
    write  = true
    delete = true
    # read  = true  # high-volume; opt in only if you need it
  }
}
```

This only stamps per-account opt-in tags (`logs_nr_sa_read` / `logs_nr_sa_write` / `logs_nr_sa_delete`). The central governance policy reads those tags and creates the Event Hub diagnostic setting itself, running as the policy remediation identity — so the deploying identity needs **no** cross-subscription Event Hub permissions. Forwarding currently targets the `swedencentral` New Relic Event Hub (new-relic-infra GH repo and subscription); accounts in other regions are not forwarded. Each category is independent.

### With static website

```hcl
module "storage" {
  source = "..."

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "westeurope"

  static_website = {
    enabled            = true
    index_document     = "index.html"
    error_404_document = "404.html"
  }
}
```

Requires `account_kind = "StorageV2"`. The static website endpoint is exposed via the `primary_web_endpoint` output.

### With SFTP and hierarchical namespace (Data Lake Gen2)

```hcl
module "storage" {
  source = "..."

  name                = "mystorageaccount"
  resource_group_name = "my-resource-group"
  location            = "westeurope"

  hierarchical_namespace_enabled = true
  sftp_enabled                   = true
}
```

`hierarchical_namespace_enabled` must be `true` to enable SFTP.

## Breaking changes

### Public access disabled by default

The default value of `public_access.enabled` changed from `true` to `false`. Existing deployments that relied on the implicit default will have their network rules flipped to `Deny` on the next apply.

To preserve previous behaviour, explicitly set:

```hcl
public_access = {
  enabled = true
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| `name` | Name of the storage account | `string` | — | yes |
| `resource_group_name` | Resource group to deploy into | `string` | — | yes |
| `location` | Azure region | `string` | — | yes |
| `tags` | Tags to assign to all resources | `map(string)` | `{}` | no |
| `account_kind` | StorageV2, BlobStorage, FileStorage, BlockBlobStorage | `string` | `"StorageV2"` | no |
| `account_tier` | Standard or Premium | `string` | `"Standard"` | no |
| `account_replication_type` | LRS, GRS, RAGRS, ZRS, GZRS, RA_GZRS | `string` | `"LRS"` | no |
| `containers` | Set of container names to create | `set(string)` | `[]` | no |
| `sas_policy_expiration_period` | SAS token expiry in `DD.HH:MM:SS` format | `string` | `"7.00:00:00"` | no |
| `shared_access_key_enabled` | Allow Shared Key authorisation; set false to enforce Azure AD only | `bool` | `true` | no |
| `allowed_copy_scope` | Restrict copy source to `AAD` or `PrivateLink` | `string` | `"AAD"` | no |
| `default_to_oauth_authentication` | Default portal auth to Azure AD | `bool` | `false` | no |
| `hierarchical_namespace_enabled` | Enable HNS / Data Lake Gen2 | `bool` | `false` | no |
| `sftp_enabled` | Enable SFTP (requires HNS) | `bool` | `false` | no |
| `allow_nested_items_to_be_public` | Allow blobs/containers to be individually made public | `bool` | `false` | no |
| `public_access` | Public network access config (see below) | `object` | `{}` (disabled) | no |
| `do_not_manage_public_access` | Skip managing network rules entirely | `bool` | `false` | no |
| `private_access` | Private endpoint config (see below) | `object` | disabled | no |
| `diagnostic_settings` | Log Analytics diagnostic config (see below) | `object` | disabled | no |
| `newrelic_storage_logs` | Per-category opt-in for forwarding data-plane logs to New Relic (see below) | `object` | `{}` (none) | no |
| `blob_properties` | Versioning, change feed, last access time | `object` | `{}` | no |
| `static_website` | Static website config (see below) | `object` | disabled | no |

### `public_access` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `enabled` | `bool` | `false` | Enable public network access |
| `bypass` | `list(string)` | `["AzureServices"]` | Services that bypass network rules |
| `ip_rules` | `list(string)` | `[]` | Allowed public IP ranges |
| `virtual_network_subnet_ids` | `list(string)` | `[]` | Allowed subnet IDs |

### `private_access` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `enabled` | `bool` | — | Enable private endpoints |
| `subnet_id` | `string` | — | Subnet to attach endpoints to |
| `subresources` | `map(object)` | — | Map of subresource name → endpoint config (blob, file, queue, table, web, dfs) |

Each subresource entry accepts `name` (override endpoint name), `private_dns_zone_id`, and `private_ip_address` (all optional).

### `diagnostic_settings` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `enabled` | `bool` | `false` | Send audit logs to Log Analytics |
| `log_analytics_workspace_id` | `string` | — | Target workspace resource ID |

### `newrelic_storage_logs` object

Opt in to forwarding Storage Account data-plane logs to New Relic, per category. The module only stamps the corresponding opt-in tag(s) on the account; the central governance policy reads them and creates the Event Hub diagnostic setting. Unset categories are not tagged and not forwarded.

| Attribute | Type | Default | Tag set when `true` | Log category |
|-----------|------|---------|---------------------|--------------|
| `read` | `bool` | `false` | `logs_nr_sa_read` | StorageRead (high volume) |
| `write` | `bool` | `false` | `logs_nr_sa_write` | StorageWrite |
| `delete` | `bool` | `false` | `logs_nr_sa_delete` | StorageDelete |

### `blob_properties` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `versioning_enabled` | `bool` | `false` | Enable blob versioning |
| `change_feed_enabled` | `bool` | `false` | Enable change feed |
| `change_feed_retention_in_days` | `number` | `null` | Retention window for change feed |
| `last_access_time_enabled` | `bool` | `false` | Track last access time |

### `static_website` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `enabled` | `bool` | `false` | Enable static website hosting |
| `index_document` | `string` | `"index.html"` | Default index document |
| `error_404_document` | `string` | `null` | Custom 404 document |

## Outputs

| Name | Description | Sensitive |
|------|-------------|-----------|
| `id` | Storage account resource ID | no |
| `name` | Storage account name | no |
| `containers` | Map of container resources | no |
| `primary_blob_endpoint` | Primary blob service endpoint URL | no |
| `primary_web_endpoint` | Static website endpoint URL | no |
| `private_endpoint_ip_addresses` | Map of subresource → private IP address | no |
| `primary_connection_string` | Primary connection string | yes |
| `secondary_connection_string` | Secondary connection string | yes |

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
| ---- | ------- |
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~> 4.0 |

## Providers

| Name | Version |
| ---- | ------- |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 4.64.0 |

## Modules

No modules.

## Resources

| Name | Type |
| ---- | ---- |
| [azurerm_monitor_diagnostic_setting.diag_settings](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_private_endpoint.pe](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/private_endpoint) | resource |
| [azurerm_storage_account.sa](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account) | resource |
| [azurerm_storage_account_network_rules.network_rules](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_network_rules) | resource |
| [azurerm_storage_account_static_website.web](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account_static_website) | resource |
| [azurerm_storage_container.containers](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_container) | resource |

## Inputs

| Name | Description | Type | Default | Required |
| ---- | ----------- | ---- | ------- | :------: |
| <a name="input_account_kind"></a> [account\_kind](#input\_account\_kind) | The Kind of account. Valid options are StorageV2, BlobStorage, FileStorage, BlockBlobStorage. | `string` | `"StorageV2"` | no |
| <a name="input_account_replication_type"></a> [account\_replication\_type](#input\_account\_replication\_type) | The type of replication to use for this storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS, RA\_GZRS. | `string` | `"LRS"` | no |
| <a name="input_account_tier"></a> [account\_tier](#input\_account\_tier) | The Tier to use for this storage account. Valid options are Standard and Premium | `string` | `"Standard"` | no |
| <a name="input_allow_nested_items_to_be_public"></a> [allow\_nested\_items\_to\_be\_public](#input\_allow\_nested\_items\_to\_be\_public) | Defaults to false. If set to true, allows nested items (blobs, files, queues, tables) to be public even if the storage account has public access disabled | `bool` | `false` | no |
| <a name="input_allowed_copy_scope"></a> [allowed\_copy\_scope](#input\_allowed\_copy\_scope) | The scope of the allowed copy source. Valid options are PrivateLink and AAD | `string` | `"AAD"` | no |
| <a name="input_blob_properties"></a> [blob\_properties](#input\_blob\_properties) | Blob properties configuration. Additional properties may be implemented in the future. Refer to the provider documentation for more details: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account | <pre>object({<br/>    versioning_enabled            = optional(bool, false)<br/>    change_feed_enabled           = optional(bool, false)<br/>    change_feed_retention_in_days = optional(number, null)<br/>    last_access_time_enabled      = optional(bool, false)<br/>  })</pre> | `{}` | no |
| <a name="input_containers"></a> [containers](#input\_containers) | List of containers to create in the storage account | `set(string)` | `[]` | no |
| <a name="input_default_to_oauth_authentication"></a> [default\_to\_oauth\_authentication](#input\_default\_to\_oauth\_authentication) | Default to Azure Active Directory authorization in the Azure portal when accessing the Storage Account. The default value is false | `bool` | `false` | no |
| <a name="input_diagnostic_settings"></a> [diagnostic\_settings](#input\_diagnostic\_settings) | Diagnostic setting configuration | <pre>object({<br/>    enabled                    = optional(bool, true)<br/>    log_analytics_workspace_id = string<br/>  })</pre> | <pre>{<br/>  "enabled": false,<br/>  "log_analytics_workspace_id": ""<br/>}</pre> | no |
| <a name="input_do_not_manage_public_access"></a> [do\_not\_manage\_public\_access](#input\_do\_not\_manage\_public\_access) | If set to true, the module will not manage public access settings for the storage account.<br/>This is useful if you want to manage public access settings outside of this module.<br/>Content of variable "public\_access" will be ignored. | `bool` | `false` | no |
| <a name="input_enable_https_traffic_only"></a> [enable\_https\_traffic\_only](#input\_enable\_https\_traffic\_only) | Boolean flag which forces HTTPS if enabled. Defaults to true. | `bool` | `true` | no |
| <a name="input_hierarchical_namespace_enabled"></a> [hierarchical\_namespace\_enabled](#input\_hierarchical\_namespace\_enabled) | Enables Hierarchical Namespace for the storage account. Must be set to true if SFTP is enabled. | `bool` | `false` | no |
| <a name="input_location"></a> [location](#input\_location) | Specifies the supported Azure location where to create the resource. | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | Name of the storage account | `string` | n/a | yes |
| <a name="input_private_access"></a> [private\_access](#input\_private\_access) | n/a | <pre>object({<br/>    enabled   = bool<br/>    subnet_id = string<br/>    subresources = map(object({<br/>      name                = optional(string, null)<br/>      private_dns_zone_id = optional(string, null)<br/>      private_ip_address  = optional(string, null)<br/>    }))<br/>  })</pre> | <pre>{<br/>  "enabled": false,<br/>  "subnet_id": null,<br/>  "subresources": {}<br/>}</pre> | no |
| <a name="input_public_access"></a> [public\_access](#input\_public\_access) | Public access configuration for the storage account.<br/>Public access is disabled by default. Set enabled = true to allow public network access.<br/>Default action is configured to deny all requests when ip\_rules or virtual\_network\_subnet\_ids are not empty; if both are empty and enabled is true, the default action is to allow all requests. | <pre>object({<br/>    enabled                    = optional(bool, false)<br/>    bypass                     = optional(list(string), ["AzureServices"])<br/>    ip_rules                   = optional(list(string), [])<br/>    virtual_network_subnet_ids = optional(list(string), [])<br/>  })</pre> | `{}` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which the resource is created | `string` | n/a | yes |
| <a name="input_sas_policy_expiration_period"></a> [sas\_policy\_expiration\_period](#input\_sas\_policy\_expiration\_period) | The expiration period for the SAS policy. The value must be in format of `DD.HH:MM:SS`. | `string` | `"7.00:00:00"` | no |
| <a name="input_sftp_enabled"></a> [sftp\_enabled](#input\_sftp\_enabled) | Enables SFTP for the storage account. Hierarchical Namespace must be enabled to enable SFTP. | `bool` | `false` | no |
| <a name="input_shared_access_key_enabled"></a> [shared\_access\_key\_enabled](#input\_shared\_access\_key\_enabled) | Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key.<br/>If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD). | `bool` | `true` | no |
| <a name="input_static_website"></a> [static\_website](#input\_static\_website) | Static website configuration | <pre>object({<br/>    enabled            = optional(bool, true)<br/>    index_document     = optional(string, "index.html")<br/>    error_404_document = optional(string, null)<br/>  })</pre> | <pre>{<br/>  "enabled": false<br/>}</pre> | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
| ---- | ----------- |
| <a name="output_containers"></a> [containers](#output\_containers) | Storage Account Containers |
| <a name="output_id"></a> [id](#output\_id) | Storage Account ID |
| <a name="output_name"></a> [name](#output\_name) | Storage Account Name |
| <a name="output_primary_blob_endpoint"></a> [primary\_blob\_endpoint](#output\_primary\_blob\_endpoint) | Primary Blob Endpoint |
| <a name="output_primary_connection_string"></a> [primary\_connection\_string](#output\_primary\_connection\_string) | Storage account's primary connection string |
| <a name="output_primary_web_endpoint"></a> [primary\_web\_endpoint](#output\_primary\_web\_endpoint) | Primary static website endpoint |
| <a name="output_private_endpoint_ip_addresses"></a> [private\_endpoint\_ip\_addresses](#output\_private\_endpoint\_ip\_addresses) | Private Endpoint IP Address |
| <a name="output_secondary_connection_string"></a> [secondary\_connection\_string](#output\_secondary\_connection\_string) | Storage account's secondary connection string |
<!-- END_TF_DOCS -->