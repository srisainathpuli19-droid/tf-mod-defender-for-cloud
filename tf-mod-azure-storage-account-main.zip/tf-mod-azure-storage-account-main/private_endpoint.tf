resource "azurerm_private_endpoint" "pe" {
  for_each = var.private_access.enabled ? var.private_access.subresources : {}

  name = coalesce(
    each.value.name,
    "pe-${var.name}-${each.key}"
  )

  resource_group_name = var.resource_group_name
  location            = var.location

  subnet_id = var.private_access.subnet_id

  private_service_connection {
    name                           = var.name
    is_manual_connection           = false
    subresource_names              = [each.key]
    private_connection_resource_id = azurerm_storage_account.sa.id
  }

  dynamic "ip_configuration" {
    for_each = each.value.private_ip_address != null ? [1] : []

    content {
      name               = "default"
      private_ip_address = each.value.private_ip_address
    }
  }

  dynamic "private_dns_zone_group" {
    for_each = each.value.private_dns_zone_id != null ? [1] : []

    content {
      name                 = "default"
      private_dns_zone_ids = [each.value.private_dns_zone_id]
    }
  }

  tags = merge(var.tags, {
    "target-resource" = azurerm_storage_account.sa.id
  })

  lifecycle {
    ignore_changes = [
      # Managed through Azure Policy
      private_dns_zone_group
    ]
  }
}
