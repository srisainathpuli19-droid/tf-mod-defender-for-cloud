output "id" {
  description = "Storage Account ID"
  value       = azurerm_storage_account.sa.id
}

output "name" {
  description = "Storage Account Name"
  value       = azurerm_storage_account.sa.name
}

output "containers" {
  description = "Storage Account Containers"
  value       = azurerm_storage_container.containers
}

output "primary_connection_string" {
  description = "Storage account's primary connection string"
  value       = azurerm_storage_account.sa.primary_connection_string
  sensitive   = true
}

output "secondary_connection_string" {
  description = "Storage account's secondary connection string"
  value       = azurerm_storage_account.sa.secondary_connection_string
  sensitive   = true
}

output "primary_blob_endpoint" {
  description = "Primary Blob Endpoint"
  value       = azurerm_storage_account.sa.primary_blob_endpoint
}

output "private_endpoint_ip_addresses" {
  description = "Private Endpoint IP Address"
  value = {
    for subresource, pe in azurerm_private_endpoint.pe :
    subresource => pe.private_service_connection[0].private_ip_address
  }
}

output "primary_web_endpoint" {
  description = "Primary static website endpoint"
  value       = azurerm_storage_account.sa.primary_web_endpoint
}
