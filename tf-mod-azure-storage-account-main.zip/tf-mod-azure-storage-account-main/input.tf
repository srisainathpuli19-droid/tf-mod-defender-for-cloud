variable "resource_group_name" {
  description = "The name of the resource group in which the resource is created"
  type        = string
}

variable "location" {
  description = "Specifies the supported Azure location where to create the resource."
  type        = string
}

variable "name" {
  type        = string
  description = "Name of the storage account"
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "A mapping of tags to assign to the resource."
}

variable "account_kind" {
  description = "The Kind of account. Valid options are StorageV2, BlobStorage, FileStorage, BlockBlobStorage."
  type        = string
  default     = "StorageV2"

  validation {
    condition     = contains(["StorageV2", "BlobStorage", "FileStorage", "BlockBlobStorage"], var.account_kind)
    error_message = "Valid options are StorageV2, BlobStorage, FileStorage, BlockBlobStorage."
  }
}

variable "account_tier" {
  description = "The Tier to use for this storage account. Valid options are Standard and Premium"
  type        = string
  default     = "Standard"

  validation {
    condition     = contains(["Standard", "Premium"], var.account_tier)
    error_message = "Valid options are Standard and Premium."
  }
}

variable "account_replication_type" {
  description = "The type of replication to use for this storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS, RA_GZRS."
  type        = string
  default     = "LRS"

  validation {
    condition     = contains(["LRS", "GRS", "RAGRS", "ZRS", "GZRS", "RA_GZRS"], var.account_replication_type)
    error_message = "Valid options are LRS, GRS, RAGRS, ZRS, GZRS, RA_GZRS."
  }
}

variable "containers" {
  description = "List of containers to create in the storage account"
  type        = set(string)
  default     = []
}

variable "sas_policy_expiration_period" {
  description = "The expiration period for the SAS policy. The value must be in format of `DD.HH:MM:SS`."
  type        = string
  default     = "7.00:00:00"
}

variable "shared_access_key_enabled" {
  description = <<EOT
Indicates whether the storage account permits requests to be authorized with the account access key via Shared Key.
If false, then all requests, including shared access signatures, must be authorized with Azure Active Directory (Azure AD).
EOT
  type        = bool
  default     = true
}

variable "hierarchical_namespace_enabled" {
  description = "Enables Hierarchical Namespace for the storage account. Must be set to true if SFTP is enabled."
  type        = bool
  default     = false
}

variable "sftp_enabled" {
  description = "Enables SFTP for the storage account. Hierarchical Namespace must be enabled to enable SFTP."
  type        = bool
  default     = false

  validation {
    condition     = !var.sftp_enabled || var.hierarchical_namespace_enabled
    error_message = "Hierarchical Namespace must be enabled to enable SFTP."
  }
}

variable "do_not_manage_public_access" {
  type        = bool
  default     = false
  description = <<EOT
If set to true, the module will not manage public access settings for the storage account.
This is useful if you want to manage public access settings outside of this module.
Content of variable "public_access" will be ignored.
EOT
}

variable "public_access" {
  type = object({
    enabled                    = optional(bool, false)
    bypass                     = optional(list(string), ["AzureServices"])
    ip_rules                   = optional(list(string), [])
    virtual_network_subnet_ids = optional(list(string), [])
  })

  default  = {}
  nullable = false

  description = <<EOT
Public access configuration for the storage account.
Public access is disabled by default. Set enabled = true to allow public network access.
Default action is configured to deny all requests when ip_rules or virtual_network_subnet_ids are not empty; if both are empty and enabled is true, the default action is to allow all requests.
EOT
}

variable "private_access" {
  type = object({
    enabled   = bool
    subnet_id = string
    subresources = map(object({
      name                = optional(string, null)
      private_dns_zone_id = optional(string, null)
      private_ip_address  = optional(string, null)
    }))
  })
  default = {
    enabled      = false
    subnet_id    = null
    subresources = {}
  }
  nullable = false
}

variable "diagnostic_settings" {
  description = "Diagnostic setting configuration"
  type = object({
    enabled                    = optional(bool, true)
    log_analytics_workspace_id = string
  })
  default = {
    enabled                    = false
    log_analytics_workspace_id = ""
  }
}

variable "newrelic_storage_logs" {
  description = <<-EOT
    Opt in to forwarding Storage Account data-plane logs to New Relic, per category.
    This only stamps opt-in tags that the central governance policy reads; the module does NOT
    create the Event Hub diagnostic setting itself, so the deploying identity needs no
    cross-subscription Event Hub access. Each category is opted in independently:
      read   -> StorageRead   (tag "logs_nr_sa_read")
      write  -> StorageWrite  (tag "logs_nr_sa_write")
      delete -> StorageDelete (tag "logs_nr_sa_delete")
    Only enabled categories are tagged; an unset category is not forwarded.
  EOT
  type = object({
    read   = optional(bool, false)
    write  = optional(bool, false)
    delete = optional(bool, false)
  })
  default = {}
}

variable "blob_properties" {
  type = object({
    versioning_enabled            = optional(bool, false)
    change_feed_enabled           = optional(bool, false)
    change_feed_retention_in_days = optional(number, null)
    last_access_time_enabled      = optional(bool, false)
  })
  default     = {}
  description = "Blob properties configuration. Additional properties may be implemented in the future. Refer to the provider documentation for more details: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_account"
}

variable "allowed_copy_scope" {
  description = "The scope of the allowed copy source. Valid options are PrivateLink and AAD"
  type        = string
  default     = "AAD"

  validation {
    condition     = contains(["PrivateLink", "AAD"], var.allowed_copy_scope)
    error_message = "Valid options are PrivateLink and AAD."
  }
}

variable "default_to_oauth_authentication" {
  description = "Default to Azure Active Directory authorization in the Azure portal when accessing the Storage Account. The default value is false"
  type        = bool
  default     = false
}

variable "static_website" {
  description = "Static website configuration"
  type = object({
    enabled            = optional(bool, true)
    index_document     = optional(string, "index.html")
    error_404_document = optional(string, null)
  })
  default = {
    enabled = false
  }
}

variable "enable_https_traffic_only" {
  description = "Boolean flag which forces HTTPS if enabled. Defaults to true."
  type        = bool
  default     = true
}

variable "allow_nested_items_to_be_public" {
  description = "Defaults to false. If set to true, allows nested items (blobs, files, queues, tables) to be public even if the storage account has public access disabled"
  type        = bool
  default     = false
}
