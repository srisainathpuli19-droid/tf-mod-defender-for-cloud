#--------------------------------------------------------------
# Defender for Storage — Per-Resource
#--------------------------------------------------------------
resource "azurerm_security_center_storage_defender" "this" {
  for_each = { for sa in var.storage_accounts : sa.storage_account_id => sa }

  storage_account_id                          = each.value.storage_account_id
  override_subscription_settings_enabled      = each.value.override_subscription_settings_enabled
  malware_scanning_on_upload_enabled          = each.value.malware_scanning_on_upload_enabled
  malware_scanning_on_upload_cap_gb_per_month = each.value.malware_scanning_on_upload_cap_gb_per_month
  sensitive_data_discovery_enabled            = each.value.sensitive_data_discovery_enabled
  scan_results_event_grid_topic_id            = each.value.scan_results_event_grid_topic_id
}

#--------------------------------------------------------------
# Advanced Threat Protection — Per-Resource (Key Vaults, Cosmos DB, etc.)
#--------------------------------------------------------------
resource "azurerm_advanced_threat_protection" "this" {
  for_each = toset(var.advanced_threat_protection_resource_ids)

  target_resource_id = each.value
  enabled            = true
}
