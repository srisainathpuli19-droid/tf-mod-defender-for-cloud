#--------------------------------------------------------------
# Defender for Storage — Per-Resource
#--------------------------------------------------------------
variable "storage_accounts" {
  description = <<-EOT
    List of storage accounts to enable Defender for Storage on individually.
    Each entry targets a specific storage account by its resource ID.

    Arguments:
    - storage_account_id: Full Azure resource ID of the storage account
    - override_subscription_settings_enabled: Override subscription-level Defender settings (default: true)
    - malware_scanning_on_upload_enabled: Enable on-upload malware scanning (default: true)
    - malware_scanning_on_upload_cap_gb_per_month: Max GB scanned per month, -1 for unlimited (default: -1)
    - sensitive_data_discovery_enabled: Enable sensitive data discovery (default: true)
    - scan_results_event_grid_topic_id: Event Grid topic for scan results (default: null)
  EOT
  type = list(object({
    storage_account_id                          = string
    override_subscription_settings_enabled      = optional(bool, true)
    malware_scanning_on_upload_enabled          = optional(bool, true)
    malware_scanning_on_upload_cap_gb_per_month = optional(number, -1)
    sensitive_data_discovery_enabled            = optional(bool, true)
    scan_results_event_grid_topic_id            = optional(string, null)
  }))
  default  = []
  nullable = false
}

#--------------------------------------------------------------
# Advanced Threat Protection — Per-Resource (Key Vaults, Cosmos DB, etc.)
#--------------------------------------------------------------
variable "advanced_threat_protection_resource_ids" {
  description = <<-EOT
    List of Azure resource IDs to enable Advanced Threat Protection on.
    Supported resource types: Key Vaults, Cosmos DB accounts, Storage Accounts (legacy).
    Use this for resources that do not have a dedicated per-resource Defender resource.
  EOT
  type        = list(string)
  default     = []
  nullable    = false
}
