output "storage_defender_ids" {
  description = "Map of storage account IDs to their Defender for Storage resource IDs."
  value = {
    for k, v in azurerm_security_center_storage_defender.this : k => v.id
  }
}

output "advanced_threat_protection_ids" {
  description = "Map of target resource IDs to their Advanced Threat Protection resource IDs."
  value = {
    for k, v in azurerm_advanced_threat_protection.this : k => v.id
  }
}
