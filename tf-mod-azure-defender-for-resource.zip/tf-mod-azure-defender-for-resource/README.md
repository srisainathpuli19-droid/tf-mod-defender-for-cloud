# Defender for Resource module

Terraform module for enabling **Microsoft Defender** on specific individual Azure resources by their resource ID — enabling protection on only the resources you choose, not the entire subscription.

## Supported Per-Resource Defender Types

| Resource Type | Terraform Resource | Features |
|---|---|---|
| Storage Accounts | `azurerm_security_center_storage_defender` | Malware scanning, sensitive data discovery, Event Grid, GB cap |
| Key Vaults | `azurerm_advanced_threat_protection` | Enable/disable ATP |
| Cosmos DB | `azurerm_advanced_threat_protection` | Enable/disable ATP |

## Requirements

- Terraform `>= 1.5`
- `azurerm` provider `~> 4.0`

## Usage

### Enable Defender on specific storage accounts

```hcl
module "defender_for_resource" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-resource.git?ref=<version>"

  storage_accounts = [
    {
      storage_account_id                     = "/subscriptions/xxx/resourceGroups/rg-prod/providers/Microsoft.Storage/storageAccounts/critical-data-sa"
      malware_scanning_on_upload_enabled     = true
      malware_scanning_on_upload_cap_gb_per_month = 5000
      sensitive_data_discovery_enabled       = true
    },
  ]
}
```

### Enable Defender on specific key vaults

```hcl
module "defender_for_resource" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-resource.git?ref=<version>"

  advanced_threat_protection_resource_ids = [
    "/subscriptions/xxx/resourceGroups/rg-prod/providers/Microsoft.KeyVault/vaults/critical-kv",
  ]
}
```

### Combined — protect specific storage accounts AND key vaults

```hcl
module "defender_for_resource" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-resource.git?ref=<version>"

  storage_accounts = [
    {
      storage_account_id                 = "/subscriptions/xxx/resourceGroups/rg-prod/providers/Microsoft.Storage/storageAccounts/sensitive-data-sa"
      malware_scanning_on_upload_enabled = true
      sensitive_data_discovery_enabled   = true
    },
  ]

  advanced_threat_protection_resource_ids = [
    "/subscriptions/xxx/resourceGroups/rg-prod/providers/Microsoft.KeyVault/vaults/secrets-kv",
    "/subscriptions/xxx/resourceGroups/rg-prod/providers/Microsoft.DocumentDB/databaseAccounts/critical-cosmosdb",
  ]
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| `storage_accounts` | List of storage accounts to enable Defender on (see below) | `list(object)` | `[]` | no |
| `advanced_threat_protection_resource_ids` | List of resource IDs to enable ATP on (Key Vaults, Cosmos DB) | `list(string)` | `[]` | no |

### `storage_accounts` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `storage_account_id` | `string` | — | Full resource ID of the storage account |
| `override_subscription_settings_enabled` | `bool` | `true` | Override subscription-level Defender settings |
| `malware_scanning_on_upload_enabled` | `bool` | `true` | Enable on-upload malware scanning |
| `malware_scanning_on_upload_cap_gb_per_month` | `number` | `-1` | Max GB scanned per month (-1 = unlimited) |
| `sensitive_data_discovery_enabled` | `bool` | `true` | Enable sensitive data discovery |
| `scan_results_event_grid_topic_id` | `string` | `null` | Event Grid topic ID for scan results |

## Outputs

| Name | Description | Sensitive |
|------|-------------|-----------|
| `storage_defender_ids` | Map of storage account IDs to Defender resource IDs | no |
| `advanced_threat_protection_ids` | Map of resource IDs to ATP resource IDs | no |

## References

- [Defender for Storage per-resource](https://learn.microsoft.com/en-us/azure/defender-for-cloud/defender-for-storage-introduction)
- [azurerm_security_center_storage_defender](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_storage_defender)
- [azurerm_advanced_threat_protection](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/advanced_threat_protection)

<!-- BEGIN_TF_DOCS -->
<!-- END_TF_DOCS -->
