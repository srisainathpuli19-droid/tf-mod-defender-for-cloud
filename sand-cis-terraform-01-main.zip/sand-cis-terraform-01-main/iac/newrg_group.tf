locals {
  resource_groups = toset([
    "shared",
    "poc",
    "database",
    "poc-verceltool",
    "Kinaxis"
  ])
}


module "naming_convention_rg" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7"

  for_each = local.resource_groups

  environment     = var.environment
  region          = var.region_name
  contextual_name = each.key
}

resource "azurerm_resource_group" "rg" {
  for_each = local.resource_groups

  name     = module.naming_convention_rg[each.key].resource_group
  location = var.location
  tags     = module.tagging_convention.tags
}
