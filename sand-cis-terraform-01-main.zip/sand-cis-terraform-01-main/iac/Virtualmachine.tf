module "windows_vm" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-windows-virtual-machine.git?ref=v3.3.0"

  name                = "OSNW10W698S"
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location

  sku      = "Standard_D2s_v5"
  username = "adminuser"

  subnet_id          = azurerm_subnet.subnet.id
  private_ip_address = null


  source_image_reference = {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2022-datacenter-g2"
    version   = "latest"
  }

  os_disk_type = "StandardSSD_LRS"

  key_vault_id = azurerm_key_vault.vm_passwords.id

  data_disks = {
    data1 = {
      lun     = 0
      size_gb = 64
      type    = "StandardSSD_LRS"
      caching = "ReadWrite"
    }
  }

  azure_monitor_agent = {
    enabled = true
  }

  auto_shutdown = {
    enabled       = true
    shutdown_time = "2100"
    timezone      = "Romance Standard Time"
  }

  trusted_launch_enabled = true

  backup = {
    recovery_vault_name           = module.rsv.name
    recovery_vault_resource_group = azurerm_resource_group.cis-terraform-01.name
    backup_policy_id              = module.rsv.gold_vm_backup_policy_id
  }

  #Disk encryption#


  disk_encryption = {
    enabled                = true
    key_vault_id           = azurerm_key_vault.vm_passwords.id
    key_vault_url          = null
    key_encryption_key_url = null
  }


  tags = module.tagging_convention.tags_for_vm[0]

  depends_on = [azurerm_role_assignment.keyvault_admin]
}



#VM2

module "linux_vm1" {
  source              = "git::https://github.com/opella-innersource/tf-mod-azure-linux-virtual-machine?ref=v7.0.0"
  name                = "OSNL10W233F"
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location
  sku                 = "Standard_B8s_v2"
  username            = "adminuser"
  subnet_id           = azurerm_subnet.subnet.id
  private_ip_address  = null
  source_image_reference = {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
  os_disk_type    = "StandardSSD_LRS"
  os_disk_size_gb = 128

  key_vault_id = azurerm_key_vault.vm_passwords.id

  data_disks = {
    data1 = {
      lun     = 0
      size_gb = 128
      type    = "StandardSSD_LRS"
      caching = "ReadWrite"
    }
  }
  azure_monitor_agent = {
    enabled = true
  }
  # auto_shutdown = {
  #   enabled       = true
  #   shutdown_time = "2100"
  #   timezone      = "Romance Standard Time"
  # }
  trusted_launch_enabled = true
  backup = {
    recovery_vault_name           = module.rsv.name
    recovery_vault_resource_group = azurerm_resource_group.cis-terraform-01.name
    backup_policy_id              = module.rsv.gold_vm_backup_policy_id
  }
  tags       = module.tagging_convention.tags_for_vm[0]
  depends_on = [azurerm_role_assignment.keyvault_admin]

}

module "linux_vm2" {
  source              = "git::https://github.com/opella-innersource/tf-mod-azure-linux-virtual-machine?ref=v7.0.0"
  name                = "MXDRTESTVM"
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location
  sku                 = "Standard_B8s_v2"
  username            = "adminuser"
  subnet_id           = azurerm_subnet.subnet.id
  private_ip_address  = null
  source_image_reference = {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
  os_disk_type    = "StandardSSD_LRS"
  os_disk_size_gb = 128

  key_vault_id = azurerm_key_vault.vm_passwords.id

  azure_monitor_agent = {
    enabled = true
  }
  trusted_launch_enabled = true
  tags                   = module.tagging_convention.tags_for_vm[0]
  depends_on             = [azurerm_role_assignment.keyvault_admin]

}

#POC Vercel like tool for opella
module "POC_linux_vm" {
  source              = "git::https://github.com/opella-innersource/tf-mod-azure-linux-virtual-machine?ref=v7.0.0"
  name                = "OSNL10W234F"
  resource_group_name = azurerm_resource_group.rg["poc-verceltool"].name
  location            = var.location
  sku                 = "Standard_D16s_v5"
  username            = "adminuser"
  subnet_id           = azurerm_subnet.subnet.id
  private_ip_address  = null
  source_image_reference = {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }
  os_disk_type    = "StandardSSD_LRS"
  os_disk_size_gb = 128

  key_vault_id = azurerm_key_vault.vm_passwords.id


  azure_monitor_agent = {
    enabled = true
    # data_collection_rules = {
    #   syslog = var.linux_syslog_dcr_id
    # }
  }
  # auto_shutdown = {
  #   enabled       = true
  #   shutdown_time = "2100"
  #   timezone      = "Romance Standard Time"
  # }
  trusted_launch_enabled = true
  backup = {
    recovery_vault_name           = module.rsv.name
    recovery_vault_resource_group = azurerm_resource_group.cis-terraform-01.name
    backup_policy_id              = module.rsv.gold_vm_backup_policy_id
  }
  tags       = module.tagging_convention.tags_for_vm[0]
  depends_on = [azurerm_role_assignment.keyvault_admin]

}


module "windows_vm2" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-windows-virtual-machine.git?ref=v3.3.0"

  name                = "OSNW10L321T"
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location

  sku      = "Standard_D2s_v5"
  username = "adminuser"

  subnet_id          = azurerm_subnet.subnet.id
  private_ip_address = null


  source_image_reference = {
    publisher = "MicrosoftWindowsServer"
    offer     = "WindowsServer"
    sku       = "2022-datacenter-g2"
    version   = "latest"
  }

  os_disk_type = "StandardSSD_LRS"

  key_vault_id = azurerm_key_vault.vm_passwords.id

  data_disks = {
    data1 = {
      lun     = 0
      size_gb = 64
      type    = "StandardSSD_LRS"
      caching = "ReadWrite"
    }
  }

  azure_monitor_agent = {
    enabled = true
  }

  # auto_shutdown = {
  #   enabled       = true
  #   shutdown_time = "2100"
  #   timezone      = "Romance Standard Time"
  # }

  trusted_launch_enabled = true

  backup = {
    recovery_vault_name           = module.rsv.name
    recovery_vault_resource_group = azurerm_resource_group.cis-terraform-01.name
    backup_policy_id              = module.rsv.gold_vm_backup_policy_id
  }

  # #Disk encryption#


  # disk_encryption = {
  #   enabled                = true
  #   key_vault_id           = azurerm_key_vault.vm_passwords.id
  #   key_vault_url          = null
  #   key_encryption_key_url = null
  # }


  # tags = module.tagging_convention.tags_for_vm[0]

  depends_on = [azurerm_role_assignment.keyvault_admin]
}

# module "windows_vm3" {
#   source = "git::https://github.com/opella-innersource/tf-mod-azure-windows-virtual-machine.git?ref=v3.3.0"

#   name                = "OSNW10L322N"
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name
#   location            = var.location

#   sku      = "Standard_D2s_v5"
#   username = "adminuser"

#   subnet_id          = azurerm_subnet.subnet.id
#   private_ip_address = null


#   source_image_reference = {
#     publisher = "MicrosoftWindowsServer"
#     offer     = "WindowsServer"
#     sku       = "2022-datacenter-g2"
#     version   = "latest"
#   }

#   os_disk_type = "StandardSSD_LRS"

#   key_vault_id = azurerm_key_vault.vm_passwords.id

#   data_disks = {
#     data1 = {
#       lun     = 0
#       size_gb = 64
#       type    = "StandardSSD_LRS"
#       caching = "ReadWrite"
#     }
#   }

#   azure_monitor_agent = {
#     enabled = true
#   }

#   auto_shutdown = {
#     enabled       = true
#     shutdown_time = "2100"
#     timezone      = "Romance Standard Time"
#   }

#   trusted_launch_enabled = true

#   backup = {
#     recovery_vault_name           = module.rsv.name
#     recovery_vault_resource_group = azurerm_resource_group.cis-terraform-01.name
#     backup_policy_id              = module.rsv.gold_vm_backup_policy_id
#   }

#   # #Disk encryption#


#   # disk_encryption = {
#   #   enabled                = true
#   #   key_vault_id           = azurerm_key_vault.vm_passwords.id
#   #   key_vault_url          = null
#   #   key_encryption_key_url = null
#   # }


#   tags = module.tagging_convention.tags_for_vm[0]

#   depends_on = [azurerm_role_assignment.keyvault_admin]
# }
