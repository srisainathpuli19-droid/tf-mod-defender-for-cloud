#PostgresSQL 
# module "public_pgsql_server" {
#   source = "git::https://github.com/opella-innersource/tf-mod-azure-postgresql.git?ref=v2"
#   #source              = "git::https://github.com/opella-innersource/tf-mod-azure-postgresql.git?ref=v2"
#   name                = "pg-db-cis-pb"
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name
#   location            = var.location

#   password_auth = {
#     enabled             = true
#     administrator_login = "pgadmin"
#     key_vault_id        = azurerm_key_vault.vm_passwords.id
#     #administrator_password_version = 1
#   }

#   sku_name   = "B_Standard_B2s"
#   storage_mb = 32768
#   pg_version = "16"

#   #public_network_access_enabled = false
#   public_access = {
#     enabled      = true
#     ip_addresses = ["167.103.23.88/32", "192.168.29.88/32"]
#   }
# }


module "private_pgsql_server" {
  source              = "git::https://github.com/opella-innersource/tf-mod-azure-postgresql.git?ref=v2"
  name                = "pg-db-cis-pv"
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location

  password_auth = {
    enabled             = true
    administrator_login = "pgadmin"
    key_vault_id        = azurerm_key_vault.vm_passwords.id
  }

  sku_name = "B_Standard_B1ms" #GP_Standard_D2ds_v5

  storage_mb = 32768
  pg_version = "16"

  public_access = {
    enabled = false
  }

  private_access = {
    enabled   = true
    subnet_id = azurerm_subnet.subnet.id
    subresources = {
      "postgresqlServer" = {}
    }
  }

  server_configurations = {
    ssl_min_protocol_version = "TLSV1.3"
    ssl_max_protocol_version = "TLSV1.3"

    "azure.extensions"           = "PGAUDIT"
    shared_preload_libraries     = "pgaudit"
    "pgaudit.log"                = "ddl,write"
    "pgaudit.log_catalog"        = "off"
    "pgaudit.log_parameter"      = "on"
    "pgaudit.log_relation"       = "on"
    "pgaudit.log_statement_once" = "on"
    "pgaudit.log_level"          = "log"
  }

  # high_availability = {
  #   enabled      = true
  #   mode         = "ZoneRedundant"
  #   standby_zone = 2
  # }
  zone = "1"
}

