locals {
  key_vaults = [
    {
      name = "fivetran",
      role_assignments = {
        vault_administrators  = [data.azurerm_client_config.current.object_id]
        certificates_officers = []
        secrets_officers      = []
        secrets_users         = []
        vault_readers         = []
      }
    }
  ]
}


locals {
  windows_vms = {
    infratestvm = {
      name                = "OSNW10H205I"
      resource_group_name = azurerm_resource_group.rg["shared"].name
      location            = var.location
      sku                 = "Standard_D2s_v5"
      subnet_id           = azurerm_subnet.subnet.id
      key_vault_id        = azurerm_key_vault.vm_passwords.id
      zone                = 1

      source_image_reference = {
        publisher = "MicrosoftWindowsServer"
        offer     = "WindowsServer"
        sku       = "2022-datacenter-g2"
        version   = "latest"
      }

      os_disk_type    = "Standard_LRS"
      os_disk_size_gb = 128


      data_disks = {
        disk1 = {
          lun                  = 0
          size_gb              = 128
          storage_account_type = "Standard_LRS"
          name                 = "infratest"
          caching              = "ReadWrite"
          # network_access_policy         = "AllowPrivate"
          # public_network_access_enabled = false
        }
      }

      backup = {
        recovery_vault_name           = module.rsv.name
        recovery_vault_resource_group = module.rsv.resource_group_name
        backup_policy_id              = module.rsv.default_vm_backup_policy_id
      }

      trusted_launch_enabled = true

      tags = module.tagging_convention.tags_for_vm[0]
    }
  }
} #craeate new vm here from now onwards

locals {
  linux_vms = {
    poc_vms = {
      name                = "OSNL10W235F"
      resource_group_name = azurerm_resource_group.rg["Kinaxis"].name
      location            = var.location
      sku                 = var.vm_sku

      subnet_id    = azurerm_subnet.subnet.id
      key_vault_id = azurerm_key_vault.vm_passwords.id
      zone         = 1

      source_image_reference = {
        publisher = "Canonical"
        offer     = "0001-com-ubuntu-server-jammy"
        sku       = "22_04-lts-gen2"
        version   = "latest"
      }

      os_disk_type    = var.os_disk_type
      os_disk_size_gb = var.os_disk_size_gb

      data_disks = {
        app = {
          lun                  = 0
          size_gb              = 128
          storage_account_type = "Standard_LRS"
        }
      }

      backup                 = null
      trusted_launch_enabled = false

      tags = merge(
        module.tagging_convention.tags_for_vm[0],
        {
          Application_id = "APM0076379"
        }
      )
    },
    poc_vm_coolify = {
      name                = "OSNL10W236F"
      resource_group_name = azurerm_resource_group.rg["poc"].name
      location            = var.location
      sku                 = var.vm_sku

      subnet_id    = azurerm_subnet.subnet.id
      key_vault_id = azurerm_key_vault.vm_passwords.id
      zone         = 1

      source_image_reference = {
        publisher = "Canonical"
        offer     = "0001-com-ubuntu-server-jammy"
        sku       = "22_04-lts-gen2"
        version   = "latest"
      }

      os_disk_type    = var.os_disk_type
      os_disk_size_gb = var.os_disk_size_gb

      data_disks = {
        app = {
          lun                  = 0
          size_gb              = 128
          storage_account_type = "Standard_LRS"
        }
      }

      backup                 = null
      trusted_launch_enabled = false

      tags = module.tagging_convention.tags_for_vm[1]

    }
  }
}

locals {
  cosmos_db = {
    cosmos-mongo-eu01-sand-01 = {
      geo_locations = [
        {
          location          = var.location
          failover_priority = 0
        }
      ]

      # consistency_policy = {
      #   consistency_level = "Session"
      # }
      throughput = 400

      databases = {
        mongodb = {
          name       = "mongodb"
          throughput = 400
        }
      }
      public_network_access_enabled = false


      private_access = {
        enabled   = true
        subnet_id = azurerm_subnet.subnet.id

        subresources = {
          MongoDB = {}
        }
      }
    }
  }
}