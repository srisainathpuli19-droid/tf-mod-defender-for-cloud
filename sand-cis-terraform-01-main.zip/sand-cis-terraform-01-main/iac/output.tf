# output "primary_access_key" {
#   value       = module.redis_test.primary_access_key
#   description = "Primary access key for Redis database"
#   sensitive   = true
# }

# output "secondary_access_key" {
#   value       = module.redis_test.secondary_access_key
#   description = "Secondary access key for Redis database"
#   sensitive   = true
# }