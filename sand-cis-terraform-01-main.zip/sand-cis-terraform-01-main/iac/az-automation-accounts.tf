# Naming_Module
# module "naming_convention_automation_accounts" {
#   source          = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7.7.0"
#   for_each        = var.automation_accounts
#   environment     = var.environment
#   region          = var.region_name
#   contextual_name = each.value.name
# }

# # Automation_Account_Module
# module "automation_account_test" {
#   source              = "git::https://github.com/opella-innersource/tf-mod-azure-automation-account?ref=v1.0.0"
#   for_each            = var.automation_accounts
#   name                = module.naming_convention_automation_accounts[each.key].automation_account
#   location            = var.location
#   resource_group_name = azurerm_resource_group.resourcegroup[each.value.resource_group_key].name
#   sku                 = each.value.sku

#   # Runbooks details:
#   automation_runbooks = {
#     for rb_key, rb in each.value.automation_runbooks : rb_key => merge(
#       rb,
#       {
#         content = file("${path.module}/${rb.script_file}")
#       }
#     )
#   }

#   # Identity:
#   managed_identities = each.value.managed_identities

#   # Hybrid-Workers 'optional'
#   hybrid_runbook_worker_groups = each.value.hybrid_runbook_worker_groups
#   hybrid_runbook_workers       = each.value.hybrid_runbook_workers

#   # Configs 'optional'
#   automation_certificates            = each.value.automation_certificates
#   automation_connection_certificates = each.value.automation_connection_certificates
#   automation_job_schedules           = each.value.automation_job_schedules
#   automation_modules                 = each.value.automation_modules
#   automation_schedules               = each.value.automation_schedules
#   automation_source_controls         = each.value.automation_source_controls
#   automation_variable_bools          = each.value.automation_variable_bools
#   automation_variable_strings        = each.value.automation_variable_strings
#   automation_variable_ints           = each.value.automation_variable_ints
#   automation_variable_datetimes      = each.value.automation_variable_datetimes
#   automation_credentials             = each.value.automation_credentials
#   automation_connections             = each.value.automation_connections
#   private_endpoints                  = each.value.private_endpoints
#   role_assignments                   = each.value.role_assignments

#   # Tags
#   tags = module.tagging_convention.tags
# }
