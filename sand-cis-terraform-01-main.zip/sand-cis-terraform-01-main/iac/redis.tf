# resource "azurerm_redis_cache" "test" {
#   name                = "redis-${var.region_name}-${var.environment}-test-cache"
#   location            = var.location
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name

#   # Standard C1 configuration (1GB, 2-node with automatic replication)
#   sku_name = "Standard"
#   capacity = 1
#   family   = "C"

#   # Security settings
#   non_ssl_port_enabled = false
#   minimum_tls_version  = "1.2"


#   # Redis configuration
#   redis_configuration {
#     maxmemory_policy = "allkeys-lru"
#   }

#   # Public network access disabled (will use private endpoint)
#   public_network_access_enabled = false

#   tags = module.tagging_convention.tags
# }

# #endpoint creation 
# resource "azurerm_private_endpoint" "redis" {
#   name                = "pe-redis-${var.region_name}-${var.environment}-test-cache"
#   location            = var.location
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name
#   #subnet_id           = module.subnets["shared"].id
#   subnet_id = azurerm_subnet.subnet.id

#   private_service_connection {
#     name                           = "redis-privatelink"
#     private_connection_resource_id = azurerm_redis_cache.test.id
#     is_manual_connection           = false
#     subresource_names              = ["redisCache"]
#   }
#   private_dns_zone_group {
#     name                 = "redis_dns_group"
#     private_dns_zone_ids = [azurerm_private_dns_zone.redis.id]
#   }

# }

# resource "azurerm_private_dns_zone" "redis" {
#   name                = "privatelink.redis.cache.windows.net"
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name
#   tags                = module.tagging_convention.tags
# }

# resource "azurerm_private_dns_zone_virtual_network_link" "redis" {
#   name                  = "redis-dns-link"
#   resource_group_name   = azurerm_resource_group.cis-terraform-01.name
#   private_dns_zone_name = azurerm_private_dns_zone.redis.name
#   virtual_network_id    = data.azurerm_virtual_network.existing_vnet.id
#   registration_enabled  = false
# }

# resource "azurerm_private_dns_zone_group" "redis_dns_group" {
#   name                = "default"
#   private_endpoint_id = azurerm_private_endpoint.redis.id

#   private_dns_zone_configs {
#     name                = "redis-dns"
#     private_dns_zone_id = azurerm_private_dns_zone.redis.id
#   }
# }


# resource "azurerm_monitor_diagnostic_setting" "redis" {
#   name                       = "redis-diagnostics"
#   target_resource_id         = azurerm_redis_cache.test.id
#   log_analytics_workspace_id = module.la_workspace.id

#   enabled_log {
#     category = "ConnectedClientList"
#   }

#   enabled_metric { # ← Cambio aquí
#     category = "AllMetrics"
#   }
# }


# module "private_redis_server" {
#   source              = "git::https://github.com/opella-innersource/tf-mod-azure-managed-redis.git?ref=v1"
#   name                = "pe-redis-${var.region_name}-${var.environment}-test1-cache"
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name
#   location            = var.location
#   sku_name            = "Premium"
#   capacity            = 1
#   enable_non_ssl_port = false
#   private_access = {
#     enabled   = true
#     subnet_id = azurerm_subnet.subnet.id
#     subresources = {
#       redisCache = {
#         private_dns_zone_id = data.azurerm_private_dns_zone.private_redis_server.id
#       }
#     }
#   }
#   tags = module.tagging_convention.tags
#   #public_network_access_enabled = false
# }

# # resource "azurerm_private_dns_zone" "private_redis_server" {
# #   name                = "privatelink.redis.cache.windows.net"
# #   resource_group_name = azurerm_resource_group.cis-terraform-01.name
# #   tags                = module.tagging_convention.tags
# # }


# resource "azurerm_private_dns_zone" "private_redis_server" {
#   name                = "privatelink.redis.cache.windows.net"
#   resource_group_name = "rg-eu01-sand-core"

# }

# resource "azurerm_private_dns_zone_virtual_network_link" "private_redis_server" {
#   name                  = "redis-dns-link"
#   resource_group_name   = azurerm_resource_group.cis-terraform-01.name
#   private_dns_zone_name = azurerm_private_dns_zone.private_redis_server.name
#   virtual_network_id    = data.azurerm_virtual_network.existing_vnet.id
# }