module "naming_convention_resource_groups" {
  source   = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7.7.0"
  for_each = var.cis_resource_groups

  environment     = var.environment
  region          = var.region_name
  contextual_name = each.value.name # uses the "name" from the rg
}

resource "azurerm_resource_group" "resourcegroup" {
  for_each = var.cis_resource_groups

  name     = module.naming_convention_resource_groups[each.key].resource_group
  location = var.location
  tags     = module.tagging_convention.tags
}