module "shared_storage_account" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7"

  derived_from = module.naming_convention

  # Override contextual name for SA short name
  contextual_name = "internalsandboxstorage"

  # Ensure triple digits for instance (SA)
  instance_digits_count = 3
}

module "storage_account" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-storage-account.git?ref=v2.2.0"

  name                = module.shared_storage_account.storage_accounts[0]
  resource_group_name = azurerm_resource_group.rg["shared"].name
  location            = var.location

  allow_nested_items_to_be_public = true

  tags = module.tagging_convention.tags

  newrelic_storage_logs = {
    write  = true
    delete = true
  }

  containers = [
    "sharedcontent"
  ]

  public_access = {
    enabled                    = true
    ip_rules                   = var.allowed_ip_ranges
    virtual_network_subnet_ids = []
    bypass                     = ["AzureServices"]
  }

  private_access = {
    enabled   = true
    subnet_id = azurerm_subnet.subnet.id
    subresources = {
      blob = {}
      file = {}
    }
  }
}

module "storage_account_test" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-storage-account.git?ref=v1.13.0"

  name                = module.shared_storage_account.storage_accounts[1]
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location

  tags = module.tagging_convention.tags

  containers = [
    "restorecontent"
  ]

  public_access = {
    enabled                    = true
    ip_rules                   = var.allowed_ip_ranges
    virtual_network_subnet_ids = []
    bypass                     = ["AzureServices"]
  }

  private_access = {
    enabled   = true
    subnet_id = azurerm_subnet.subnet.id
    subresources = {
      blob = {}
      file = {}
    }
  }
}

