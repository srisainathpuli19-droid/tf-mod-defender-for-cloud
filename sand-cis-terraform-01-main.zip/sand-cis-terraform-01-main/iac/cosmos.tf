
module "cosmos_mongo_db" {
  source   = "git::https://github.com/opella-innersource/tf-mod-azure-cosmos-db.git?ref=v1.0.0"
  for_each = local.cosmos_db

  name                = each.key
  location            = var.location
  resource_group_name = azurerm_resource_group.rg["database"].name

  geo_locations = try(each.value.geo_locations, null)

  throughput = each.value.throughput
  databases  = each.value.databases

  public_network_access_enabled = try(each.value.public_network_access_enabled, true)
  private_access                = try(each.value.private_access, null)

  tags = module.tagging_convention.tags

}