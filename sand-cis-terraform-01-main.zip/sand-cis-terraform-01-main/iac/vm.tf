module "new_linux_vm" {
  source                 = "git::https://github.com/opella-innersource/tf-mod-azure-linux-virtual-machine?ref=v7.0.0"
  for_each               = local.linux_vms
  name                   = each.value.name
  location               = each.value.location
  resource_group_name    = each.value.resource_group_name
  subnet_id              = each.value.subnet_id
  key_vault_id           = each.value.key_vault_id
  sku                    = each.value.sku
  zone                   = each.value.zone
  os_disk_type           = each.value.os_disk_type
  os_disk_size_gb        = each.value.os_disk_size_gb
  source_image_reference = each.value.source_image_reference
  data_disks             = each.value.data_disks
  trusted_launch_enabled = each.value.trusted_launch_enabled
  backup                 = each.value.backup
  tags                   = each.value.tags
}

module "new_window_vm" {
  source                 = "git::https://github.com/opella-innersource/tf-mod-azure-windows-virtual-machine.git?ref=v6.1.0"
  for_each               = local.windows_vms
  name                   = each.value.name
  location               = each.value.location
  resource_group_name    = each.value.resource_group_name
  subnet_id              = each.value.subnet_id
  key_vault_id           = each.value.key_vault_id
  sku                    = each.value.sku
  zone                   = each.value.zone
  os_disk_type           = each.value.os_disk_type
  os_disk_size_gb        = each.value.os_disk_size_gb
  source_image_reference = each.value.source_image_reference
  data_disks             = each.value.data_disks
  trusted_launch_enabled = each.value.trusted_launch_enabled
  backup                 = each.value.backup
  tags                   = each.value.tags
}