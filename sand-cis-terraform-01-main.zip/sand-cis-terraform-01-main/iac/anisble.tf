# module "ansible_naming_convention" {
#   source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7"

#   derived_from           = module.naming_convention
#   append_contextual_name = "ansible"

#   # Ensure triple digits for instance (SA)
#   instance_digits_count = 3
# }

# module "ansible_storage_account" {
#   source = "git::https://github.com/opella-innersource/tf-mod-azure-storage-account.git?ref=v1"

#   name                = module.ansible_naming_convention.storage_accounts[0]
#   resource_group_name = azurerm_resource_group.groups["shared"].name
#   location            = var.location

#   containers = ["ansible-playbooks"]

#   tags = module.tagging_convention.tags
# }

# module "ansible_bootstrap" {
#   source = "git::https://github.com/opella-innersource/tf-mod-azure-vm-ansible-prereqs?ref=v1"

#   storage_account_id = module.ansible_storage_account.id
# }

# resource "azurerm_storage_blob" "ansible_playbooks" {
#   name                   = "ansible.zip"
#   storage_account_name   = module.ansible_storage_account.name
#   storage_container_name = module.ansible_storage_account.containers["ansible-playbooks"].name
#   type                   = "Block"

#   source      = var.ansible_playbooks_path
#   content_md5 = filemd5(var.ansible_playbooks_path)
# }

# data "azurerm_storage_account_sas" "ansible" {
#   connection_string = module.ansible_storage_account.primary_connection_string

#   https_only = true

#   start  = formatdate("YYYY-MM-DD'T'hh:mm:ssZ", timeadd(timestamp(), "-5m"))
#   expiry = formatdate("YYYY-MM-DD'T'hh:mm:ssZ", timeadd(timestamp(), "1h"))

#   services {
#     blob  = true
#     queue = false
#     table = false
#     file  = false
#   }

#   resource_types {
#     service   = false
#     container = true
#     object    = true
#   }

#   permissions {
#     read    = true
#     write   = false
#     delete  = false
#     list    = true
#     add     = false
#     create  = false
#     update  = false
#     process = false
#     tag     = false
#     filter  = false
#   }
# }