Write-Output "Sample VM"
Write-Output "Add your PowerShell code to stop the VM here"

$a = 10
$b = 20
$result = $a + $b
$result_sub = $b - $a
Write-Output "The result of $a + $b is: $result"
Write-Output "The result of $b - $a is: $result_sub"