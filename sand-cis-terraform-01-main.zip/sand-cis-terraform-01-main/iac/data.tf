data "azurerm_virtual_network" "existing_vnet" {
  name                = "vnet-${var.region_name}-${var.environment}-cis-terraform-01"
  resource_group_name = "rg-${var.region_name}-${var.environment}-core"
}