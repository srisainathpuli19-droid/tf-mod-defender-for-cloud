data "azurerm_client_config" "current" {}

module "naming_convention" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7"

  environment     = var.environment
  region          = var.region_name
  contextual_name = "cis-terraform-01"

}

module "tagging_convention" {
  source         = "git::https://github.com/opella-innersource/tf-mod-azure-tagging-convention?ref=v2.2.0"
  environment    = var.environment
  region         = var.region_name
  application_id = "AZFOUNDATION"
  app_category   = "bronze"

}

resource "azurerm_resource_group" "cis-terraform-01" {
  name     = module.naming_convention.resource_group
  location = var.location
  tags     = module.tagging_convention.tags
}

resource "azurerm_subnet" "subnet" {
  name                 = module.naming_convention.subnet
  resource_group_name  = data.azurerm_virtual_network.existing_vnet.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing_vnet.name
  address_prefixes     = ["10.242.20.64/27"]

  private_endpoint_network_policies = "Disabled"

}

module "keyvault_naming" {
  source                 = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7"
  derived_from           = module.naming_convention
  append_contextual_name = "vmpass"
}

resource "azurerm_key_vault" "vm_passwords" {
  name                        = module.keyvault_naming.key_vaults[1]
  location                    = var.location
  resource_group_name         = azurerm_resource_group.cis-terraform-01.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  enabled_for_disk_encryption = true
  rbac_authorization_enabled  = true

  network_acls {
    default_action = "Allow"
    bypass         = "AzureServices"
  }
}

resource "azurerm_private_endpoint" "vm_kv_pe" {
  name                = "pe-${azurerm_key_vault.vm_passwords.name}-test"
  location            = var.location
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  subnet_id           = azurerm_subnet.subnet.id

  private_service_connection {
    name                           = "kv-connection-test"
    private_connection_resource_id = azurerm_key_vault.vm_passwords.id
    is_manual_connection           = false
    subresource_names              = ["vault"]
  }
  lifecycle {
    ignore_changes = [
      private_dns_zone_group
    ]
  }
}

module "rsv" {
  source              = "git::https://github.com/opella-innersource/tf-mod-azure-recovery-services-vault?ref=v2"
  name                = module.naming_convention.recovery_services_vault
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location
}

resource "azurerm_role_assignment" "keyvault_admin" {
  scope                = azurerm_key_vault.vm_passwords.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = data.azurerm_client_config.current.object_id
}
#KeyVault End

module "law" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-log-analytics-workspace?ref=v2.1.0"

  name                = module.naming_convention.log_analytics_workspace
  resource_group_name = azurerm_resource_group.rg["shared"].name
  location            = module.naming_convention.location.primary
}
