module "key_vault" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-key-vault?ref=v1.6.0"

  name                = module.naming_convention.key_vault
  location            = var.location
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  tenant_id           = data.azurerm_client_config.current.tenant_id

  # cuts public access immediately
  public_network_access_enabled = false

  private_access = {
    enabled   = true
    subnet_id = azurerm_subnet.subnet.id

    # MUST be "vault" for Key Vault private endpoint
    subresources = {
      vault = {
        name                = "pe-${module.naming_convention.key_vault}-vault"
        private_ip_address  = null
        private_dns_zone_id = null
      }
    }
  }
}
