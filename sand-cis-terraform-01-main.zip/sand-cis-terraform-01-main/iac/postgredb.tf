module "private_pgsql_server_test" {
  source              = "git::https://github.com/opella-innersource/tf-mod-azure-postgresql.git?ref=v2.2.0"
  name                = "pg-db-cis-test"
  resource_group_name = azurerm_resource_group.cis-terraform-01.name
  location            = var.location
  sku_name            = "B_Standard_B1ms"
  storage_mb          = 32768
  pg_version          = "16"

  password_auth = {
    enabled             = true
    administrator_login = "pgadmin"
    key_vault_id        = azurerm_key_vault.vm_passwords.id
  }

  public_access = {
    enabled = false
  }

  private_access = {
    enabled   = true
    subnet_id = azurerm_subnet.subnet.id
    subresources = {
      "postgresqlServer" = {}
    }
  }

  server_configurations = {
    ssl_min_protocol_version = "TLSV1.3"
    ssl_max_protocol_version = "TLSV1.3"
  }

  zone = "1"

  databases = var.databases

  diagnostic_settings = {
    enabled                    = true
    log_analytics_workspace_id = module.law.id
  }
}