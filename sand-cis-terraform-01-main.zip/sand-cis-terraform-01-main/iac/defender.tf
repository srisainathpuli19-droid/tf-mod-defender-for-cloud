#--------------------------------------------------------------
# Defender for Cloud — Unified Module
#--------------------------------------------------------------
module "defender" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender.git?ref=v1.0.0"

  defender_plans                          = var.defender_plans
  security_contact                        = var.defender_security_contact
  alert_notifications_enabled             = var.defender_alert_notifications_enabled
  alerts_to_admins_enabled                = var.defender_alerts_to_admins_enabled
  security_center_settings                = var.defender_security_center_settings
  enable_mcsb_assignment                  = var.defender_enable_mcsb_assignment
  mcsb_assignment_name                    = var.defender_mcsb_assignment_name
  log_analytics_workspace_id              = module.law.id
  storage_accounts                        = var.defender_storage_accounts
  advanced_threat_protection_resource_ids = var.defender_advanced_threat_protection_resource_ids
  automation_rules                        = var.defender_automation_rules
}
