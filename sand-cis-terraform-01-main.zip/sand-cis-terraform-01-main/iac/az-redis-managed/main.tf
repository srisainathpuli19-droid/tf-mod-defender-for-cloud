# resource "azurerm_resource_group" "rg" {
#   name     = "rg-redis-test"
#   location = "East US" # change as needed
# }
data "azurerm_resource_group" "this" {
  name = var.resource_group_name
}
#  Redis Enterprise Cluster (AVM)
module "redis_cluster" {
  source  = "Azure/avm-res-cache-redisenterprise/azurerm"
  version = ">= 0.1.0"

  name                  = var.name
  location              = var.location
  parent_id             = data.azurerm_resource_group.this.id
  sku_name              = var.sku_name
  high_availability     = var.high_availability
  public_network_access = var.public_network_access
  private_endpoints     = var.private_endpoints
  tags                  = var.tags
}

#Redis Database (Native Resource)
resource "azurerm_redis_enterprise_database" "db" {
  name              = var.database_name
  cluster_id        = module.redis_cluster.resource_id
  client_protocol   = var.client_protocol
  clustering_policy = var.clustering_policy
  eviction_policy   = var.eviction_policy

  dynamic "module" {
    for_each = var.modules
    content {
      name = module.value
    }
  }
}
