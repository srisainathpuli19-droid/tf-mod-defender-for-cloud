# Cluster Inputs
variable "name" {
  description = "Redis Enterprise cluster name"
  type        = string
}

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "sku_name" {
  type    = string
  default = "Balanced_B0"
}

variable "high_availability" {
  type    = string
  default = "Disabled"
}

variable "public_network_access" {
  type    = string
  default = "Disabled"
}

variable "tags" {
  type    = map(string)
  default = {}
}

# Database Inputs
variable "database_name" {
  type    = string
  default = "default"
}

variable "client_protocol" {
  type    = string
  default = "Encrypted"
}

variable "clustering_policy" {
  type    = string
  default = "EnterpriseCluster"
}



variable "eviction_policy" {
  type    = string
  default = "NoEviction"
}

variable "modules" {
  description = "Redis modules"
  type        = list(string)
  default     = []
}



# variable "aof_enabled" {
#   type    = bool
#   default = false
# }

# variable "rdb_enabled" {
#   type    = bool
#   default = false
# }
variable "private_endpoints" {
  description = "Private endpoint configuration"
  type = map(object({
    name                            = optional(string)
    subnet_resource_id              = string
    private_service_connection_name = optional(string)
    resource_group_name             = optional(string)
    private_dns_zone_resource_ids   = optional(set(string), [])
  }))
  default = {}
}