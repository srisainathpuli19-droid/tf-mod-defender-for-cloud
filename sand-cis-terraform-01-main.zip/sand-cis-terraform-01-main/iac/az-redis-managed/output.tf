output "cluster_id" {
  value = module.redis_cluster.resource_id
}

output "cluster_name" {
  value = module.redis_cluster.name
}

output "hostname" {
  value = module.redis_cluster.hostname
}

output "database_id" {
  value = azurerm_redis_enterprise_database.db.id
}

# output "primary_access_key" {
#   value     = azurerm_redis_enterprise_database.db.primary_access_key
#   sensitive = true
# }

# output "secondary_access_key" {
#   value     = azurerm_redis_enterprise_database.db.secondary_access_key
#   sensitive = true
# }

output "resource_id" {
  value = module.redis_cluster.resource_id
}

output "private_endpoints" {
  description = "Private endpoints created for Redis"
  value       = module.redis_cluster.private_endpoints
}
