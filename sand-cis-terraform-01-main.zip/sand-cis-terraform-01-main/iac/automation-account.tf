# -------------------------------
# RESOURCE GROUP
# -------------------------------
resource "azurerm_resource_group" "testrg" {
  name     = "ab-test-rg"
  location = "Sweden Central"
}

# -------------------------------
# AUTOMATION ACCOUNT (WRAPPER MODULE)
# -------------------------------
module "automation_account" {
  source = "./az-automation-account"

  # Core
  name                = "ab-test-aa"
  location            = azurerm_resource_group.testrg.location
  resource_group_name = azurerm_resource_group.testrg.name
  sku                 = "Basic"

  #  System Assigned Managed Identity
  managed_identities = {
    system_assigned = true
  }

  # -------------------------------
  # RUNBOOK (PowerShell 7.2)
  # -------------------------------
  automation_runbooks = {
    ps7_runbook = {
      name            = "ps7-demo-runbook"
      location        = azurerm_resource_group.testrg.location
      runbook_type    = "PowerShell"
      runtime_version = "7.2" #fixed

      log_verbose  = true
      log_progress = true

      content = <<EOF
Write-Output "Running on PowerShell 7.2"
EOF
    }
  }

  # Optional tags
  tags = {
    environment = "sandbox"
    runtime     = "ps7.2"
  }
}
