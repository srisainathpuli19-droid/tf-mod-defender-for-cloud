module "automation_account" {
  # source = "github.com/Azure/terraform-azurerm-avm-res-automation-automationaccount?ref=main"
  source  = "Azure/avm-res-automation-automationaccount/azurerm"
  version = "0.2.0"

  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.sku

  automation_certificates            = var.automation_certificates
  automation_connection_certificates = var.automation_connection_certificates
  automation_job_schedules           = var.automation_job_schedules
  automation_modules                 = var.automation_modules
  automation_runbooks                = var.automation_runbooks
  automation_schedules               = var.automation_schedules
  automation_source_controls         = var.automation_source_controls

  automation_variable_bools     = var.automation_variable_bools
  automation_variable_strings   = var.automation_variable_strings
  automation_variable_ints      = var.automation_variable_ints
  automation_variable_datetimes = var.automation_variable_datetimes

  automation_credentials = var.automation_credentials
  automation_connections = var.automation_connections

  private_endpoints  = var.private_endpoints
  managed_identities = var.managed_identities
  role_assignments   = var.role_assignments

  lock = var.lock # ✅ fixed

  diagnostic_settings = var.diagnostic_settings
  tags                = var.tags
}