output "automation_account_id" {
  value = module.automation_account.automation_account_id
}

output "automation_account_name" {
  value = module.automation_account.automation_account_name
}

output "hybrid_service_url" {
  value = module.automation_account.hybrid_service_url
}

output "private_endpoints" {
  value = module.automation_account.private_endpoints
}

output "resource_id" {
  value = module.automation_account.resource_id
}

output "system_assigned_mi_principal_id" {
  value = module.automation_account.system_assigned_mi_principal_id
}