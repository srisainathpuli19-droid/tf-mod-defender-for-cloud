variable "name" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "sku" {
  type = string
}

# -----------------------------
# AUTOMATION RESOURCES
# -----------------------------

variable "automation_certificates" {
  type    = any
  default = {}
}

variable "automation_connection_certificates" {
  type    = any
  default = {}
}

variable "automation_job_schedules" {
  type    = any
  default = {}
}

variable "automation_modules" {
  type    = any
  default = {}
}

variable "automation_runbooks" {
  type    = any
  default = {}
}

variable "automation_schedules" {
  type    = any
  default = {}
}

variable "automation_source_controls" {
  type    = any
  default = {}
}

# -----------------------------
# VARIABLES (ALL TYPES)
# -----------------------------

variable "automation_variable_bools" {
  type    = any
  default = {}
}

variable "automation_variable_strings" {
  type    = any
  default = {}
}

variable "automation_variable_ints" {
  type    = any
  default = {}
}

variable "automation_variable_datetimes" {
  type    = any
  default = {}
}

# -----------------------------
# CONNECTIONS / CREDS
# -----------------------------

variable "automation_credentials" {
  type    = any
  default = {}
}

variable "automation_connections" {
  type    = any
  default = {}
}

# -----------------------------
# HYBRID WORKERS
# -----------------------------

variable "hybrid_runbook_worker_groups" {
  type    = any
  default = {}
}

variable "hybrid_runbook_workers" {
  type    = any
  default = {}
}

# -----------------------------
# INFRA / PLATFORM
# -----------------------------

variable "private_endpoints" {
  type    = any
  default = {}
}

variable "managed_identities" {
  type    = any
  default = {}
}

variable "role_assignments" {
  type    = any
  default = {}
}

variable "lock" {
  type    = any
  default = null
}

variable "diagnostic_settings" {
  type    = any
  default = {}
}

variable "tags" {
  type    = map(string)
  default = {}
}