<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | ~> 1.0 |
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | ~> 2.2 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~> 4.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | ~> 4.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_naming_convention"></a> [naming\_convention](#module\_naming\_convention) | git::https://github.com/opella-innersource/tf-mod-azure-naming-convention | v7 |

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group.example](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_environment"></a> [environment](#input\_environment) | Represent a final environment (dev, int, prd, …).<br/>Contrary to `environment_type`, this component cannot accept value that "group" environment together.<br/>However, an environment of "mut" is accepted for resources shared across multiple environments.<br/><br/>To avoid confusion with environment type `prod`, `prd` should be used to design the specific `production` environment. | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | Location where the resources will be deployed, e.g., swedencentral, westeurope | `string` | n/a | yes |
| <a name="input_region_name"></a> [region\_name](#input\_region\_name) | Region where the resource is deployed.<br/>Region are based on a specific naming convention and not on the Azure names.<br/><br/>Example: eu01, us01, ap01, glob (global), etc. | `string` | n/a | yes |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | The Azure subscription ID where the Azure Resources will be deployed. | `string` | `null` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->