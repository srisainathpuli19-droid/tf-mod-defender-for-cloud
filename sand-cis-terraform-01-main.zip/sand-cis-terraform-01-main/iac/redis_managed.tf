# # import {
# #   to = module.redis_test.azurerm_redis_enterprise_database.db
# #   id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${azurerm_resource_group.cis-terraform-01.name}/providers/Microsoft.Cache/redisEnterprise/managedredis-${var.environment}/databases/default"
# # }

# # Call your module
# module "redis_test" {
#   source = "./az-redis-managed" # 

#   name                = "managedredis-${var.environment}"
#   location            = var.location
#   resource_group_name = azurerm_resource_group.cis-terraform-01.name

#   sku_name = "Balanced_B0"

#   private_endpoints = {
#     redis = {
#       name                            = "pe-managedredis-${var.environment}-redisEnterprise"
#       subnet_resource_id              = azurerm_subnet.subnet.id
#       private_service_connection_name = "psc-redis"
#       resource_group_resource_id      = azurerm_resource_group.cis-terraform-01.id
#     }
#   }
#   database_name = "default"



#   # modules = [
#   #   "RedisBloom",

#   #   "RedisJSON",
#   #   "RedisTimeSeries",
#   #   "RediSearch"
#   # ]

#   tags = {
#     env = "test"
#   }
# }
