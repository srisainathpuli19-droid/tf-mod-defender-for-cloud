# module "linux_virtual_machine" {
#   source = "git::https://github.com/opella-innersource/tf-mod-azure-linux-virtual-machine?ref=v7.1.0"

#   for_each            = var.linux_vm_test
#   name                = each.value.name
#   location            = var.location
#   resource_group_name = azurerm_resource_group.resourcegroup[each.value.resource_group_name].name
#   sku                 = each.value.sku
#   os_disk_size_gb     = each.value.os_disk_size_gb
#   os_disk_type        = each.value.os_disk_type
#   subnet_id           = azurerm_subnet.subnet.id
#   key_vault_id        = azurerm_key_vault.vm_passwords.id
#   data_disks          = each.value.data_disks
#   source_image_id     = each.value.source_image_id
#   azure_monitor_agent = each.value.azure_monitor_agent
#   # Optional Availability Zone
#   zone = lookup(each.value, "zone", null)
#   backup = {
#     recovery_vault_name           = module.rsv.name
#     recovery_vault_resource_group = module.rsv.resource_group_name
#     backup_policy_id              = module.rsv.default_vm_backup_policy_id
#   }
#   tags = module.tagging_convention.tags_for_vm[each.value.tag_index]
# }