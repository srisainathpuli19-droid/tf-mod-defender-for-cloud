# General variables

variable "subscription_id" {
  type        = string
  description = "The Azure subscription ID where the Azure Resources will be deployed."

  # Value is sourced from the ARM_SUBSCRIPTION_ID in CI environment
  default = null
}

variable "environment" {
  type        = string
  description = <<EOT
Represent a final environment (dev, int, prd, …).
Contrary to `environment_type`, this component cannot accept value that "group" environment together.
However, an environment of "mut" is accepted for resources shared across multiple environments.

To avoid confusion with environment type `prod`, `prd` should be used to design the specific `production` environment.
EOT

  validation {
    condition = contains(
      [
        "",
        "prod",
        "nonprod",
        "sand",
        "test",
        "dev",
        "stg",
        "trn",
        "uat",
      ],
    var.environment)

    error_message = "The `environment` must be one of: `prod`, `nonprod`, `sand`, `test`, `dev`, `stg`, `trn`, `uat`"
  }
}

variable "region_name" {
  type        = string
  description = <<EOT
Region where the resource is deployed.
Region are based on a specific naming convention and not on the Azure names.

Example: eu01, us01, ap01, glob (global), etc.
EOT

}

variable "location" {
  type        = string
  description = "Location where the resources will be deployed, e.g., swedencentral, westeurope"
}

variable "public_network_access_enabled" {
  type        = bool
  default     = false
  description = "Enable or disable public network access for Key Vault."
}
# variable "ansible_playbooks_path" {
#   type        = string
#   description = "The path to the Ansible playbooks artifact"
# }

variable "allowed_ip_ranges" {
  description = "List of public IP ranges allowed to access the storage account"
  type        = list(string)
}


variable "databases" {
  type = map(object({
    collation = string
    charset   = string
  }))
  description = "Databases to create on PostgreSQL server"
}

variable "cis_resource_groups" {
  type = map(object({
    name = string
  }))
  description = "Map of resource groups to create"
}

variable "linux_vm_test" {
  type = map(object({
    name                   = string
    resource_group_name    = string
    sku                    = string
    os_disk_size_gb        = number
    os_disk_type           = string
    source_image_id        = string
    trusted_launch_enabled = optional(bool)
    zone                   = optional(string, null)
    data_disks = optional(map(object({
      size_gb              = number
      storage_account_type = string
      lun                  = number
      caching              = string
      })),
    {}) #empty map
    azure_monitor_agent = optional(object({
      enabled = optional(bool, false)
      }),
    { enabled = false })
    tag_index = optional(number, 0)
  }))

  description = "Map of Windows Virtual Machines to create"
}

# variable "automation_accounts" {
#   type = map(object({
#     name               = string
#     resource_group_key = string
#     sku                = string

#     managed_identities = optional(object({
#       system_assigned = optional(bool)
#     }))

#     # Runbook
#     automation_runbooks = optional(map(object({
#       name            = string
#       description     = string
#       runbook_type    = string
#       runtime_version = optional(string)
#       log_verbose     = bool
#       log_progress    = bool
#       script_file     = string
#     })), {})

#     # Optionl
#     hybrid_runbook_worker_groups = optional(map(any), {})
#     hybrid_runbook_workers       = optional(map(any), {})

#     automation_certificates            = optional(map(any), {})
#     automation_connection_certificates = optional(map(any), {})
#     automation_job_schedules           = optional(map(any), {})
#     automation_modules                 = optional(map(any), {})
#     automation_schedules               = optional(map(any), {})
#     automation_source_controls         = optional(map(any), {})
#     automation_variable_bools          = optional(map(any), {})
#     automation_variable_strings        = optional(map(any), {})
#     automation_variable_ints           = optional(map(any), {})
#     automation_variable_datetimes      = optional(map(any), {})
#     automation_credentials             = optional(map(any), {})
#     automation_connections             = optional(map(any), {})
#     private_endpoints                  = optional(map(any), {})
#     role_assignments                   = optional(map(any), {})
#   }))
# }

variable "vm_sku" {
  description = "Azure VM size"
  type        = string
}

variable "os_disk_type" {
  description = "OS disk storage type"
  type        = string
}

variable "os_disk_size_gb" {
  description = "OS disk size in GB"
  type        = number
}

variable "linux_syslog_dcr_id" {
  description = "dcr id for mxdr testing"
  type        = string
}