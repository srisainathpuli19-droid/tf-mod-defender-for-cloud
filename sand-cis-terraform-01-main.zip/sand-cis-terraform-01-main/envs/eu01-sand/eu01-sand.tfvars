environment = "sand"
location    = "swedencentral"
region_name = "eu01"

allowed_ip_ranges = [
  "167.103.55.117",
]

databases = {
  # db1 = {
  #   collation = "en_US.utf8"
  #   charset   = "UTF8"
  # }
  # db2 = {
  #   collation = "en_US.utf8"
  #   charset   = "UTF8"
  # }
}

cis_resource_groups = {

  # aa-tst-1 = {
  #   name = "aa-tst-1"
  # }
}

linux_vm_test = {
  # vm1 = {
  #   name                = "custom-vm-test"
  #   resource_group_name = "aa-tst-1"
  #   sku                 = "Standard_D2s_v5"
  #   os_disk_size_gb     = 128
  #   os_disk_type        = "Standard_LRS"
  #   source_image_id     = "/subscriptions/4d4dcd83-c322-4f67-9c07-3b8ddf5fdaf6/resourceGroups/rg-eu01-prod-hub-management-compute-gallery/providers/Microsoft.Compute/galleries/gal.glob.prod.hub.management/images/crescendo-magnolia-author-gen2/versions/0.0.1"
  #   azure_monitor_agent = {
  #     enabled = true
  #   }
  #   data_disks = {
  #   }
  #   tag_index = 0 # "0" for patch_wave = 1
  # }
}



# VM Defaults
vm_sku          = "Standard_D4s_v5"
os_disk_type    = "Standard_LRS"
os_disk_size_gb = 64


linux_syslog_dcr_id = "/subscriptions/2e9639a5-ced9-4a16-b043-150846e121f2/resourceGroups/rg-eu01-prod-hub-cybersecurity-mxdr/providers/Microsoft.Insights/dataCollectionRules/dcr-eu01-prod-hub-cybersecurity-mxdr-linux-syslog"

#--------------------------------------------------------------
# Defender for Cloud — Sandbox Test Config
#--------------------------------------------------------------

# Subscription-level plans (minimal for sandbox)
defender_plans = [
  { resource_type = "VirtualMachines", subplan = "P2" },
  { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
  { resource_type = "KeyVaults", subplan = "PerKeyVault" },
  { resource_type = "AI" },
]

# Security contact
defender_security_contact = {
  email = "security-team@company.com"
}

defender_alert_notifications_enabled = true
defender_alerts_to_admins_enabled    = true

# Enable MDE integration
defender_security_center_settings = {
  WDATP = true
}

defender_enable_mcsb_assignment = false
defender_mcsb_assignment_name   = "mcsb"

# Per-resource: target the existing Key Vault in this sandbox
defender_advanced_threat_protection_resource_ids = [
  # Replace with the actual Key Vault resource ID from sandbox subscription
  # "/subscriptions/SUBSCRIPTION_ID/resourceGroups/RESOURCE_GROUP/providers/Microsoft.KeyVault/vaults/KEYVAULT_NAME"
]

# Per-resource: target specific storage accounts (fill in real IDs)
defender_storage_accounts = [
  # {
  #   storage_account_id                          = "/subscriptions/SUBSCRIPTION_ID/resourceGroups/RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/STORAGE_ACCOUNT_NAME"
  #   malware_scanning_on_upload_enabled          = true
  #   malware_scanning_on_upload_cap_gb_per_month = 50
  #   sensitive_data_discovery_enabled            = true
  # }
]

# Automation / continuous export rules (enable when needed)
defender_automation_rules = []
