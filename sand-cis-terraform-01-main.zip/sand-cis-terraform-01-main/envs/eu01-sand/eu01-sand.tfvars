environment = "sand"
location    = "swedencentral"
region_name = "eu01"

allowed_ip_ranges = [
  "167.103.55.117",
]

databases = {
  # db1 = {
  #   collation = "en_US.utf8"
  #   charset   = "UTF8"
  # }
  # db2 = {
  #   collation = "en_US.utf8"
  #   charset   = "UTF8"
  # }
}

cis_resource_groups = {

  # aa-tst-1 = {
  #   name = "aa-tst-1"
  # }
}

linux_vm_test = {
  # vm1 = {
  #   name                = "custom-vm-test"
  #   resource_group_name = "aa-tst-1"
  #   sku                 = "Standard_D2s_v5"
  #   os_disk_size_gb     = 128
  #   os_disk_type        = "Standard_LRS"
  #   source_image_id     = "/subscriptions/4d4dcd83-c322-4f67-9c07-3b8ddf5fdaf6/resourceGroups/rg-eu01-prod-hub-management-compute-gallery/providers/Microsoft.Compute/galleries/gal.glob.prod.hub.management/images/crescendo-magnolia-author-gen2/versions/0.0.1"
  #   azure_monitor_agent = {
  #     enabled = true
  #   }
  #   data_disks = {
  #   }
  #   tag_index = 0 # "0" for patch_wave = 1
  # }
}



# VM Defaults
vm_sku          = "Standard_D4s_v5"
os_disk_type    = "Standard_LRS"
os_disk_size_gb = 64


linux_syslog_dcr_id = "/subscriptions/2e9639a5-ced9-4a16-b043-150846e121f2/resourceGroups/rg-eu01-prod-hub-cybersecurity-mxdr/providers/Microsoft.Insights/dataCollectionRules/dcr-eu01-prod-hub-cybersecurity-mxdr-linux-syslog"
