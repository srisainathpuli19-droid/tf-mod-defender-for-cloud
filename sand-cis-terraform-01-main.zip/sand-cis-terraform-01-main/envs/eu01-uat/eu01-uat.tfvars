environment = "uat"
location    = "swedencentral"
region_name = "eu01"
