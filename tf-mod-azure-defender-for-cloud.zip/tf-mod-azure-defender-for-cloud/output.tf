output "defender_plans" {
  description = "Map of enabled Defender for Cloud plans with their resource IDs."
  value = {
    for k, v in azurerm_security_center_subscription_pricing.plans : k => {
      id            = v.id
      resource_type = v.resource_type
      tier          = v.tier
      subplan       = v.subplan
    }
  }
}

output "security_contact_id" {
  description = "The ID of the security center contact resource."
  value       = length(azurerm_security_center_contact.this) > 0 ? azurerm_security_center_contact.this[0].id : null
}

output "subscription_id" {
  description = "The subscription ID where Defender for Cloud is configured."
  value       = data.azurerm_subscription.current.subscription_id
}
