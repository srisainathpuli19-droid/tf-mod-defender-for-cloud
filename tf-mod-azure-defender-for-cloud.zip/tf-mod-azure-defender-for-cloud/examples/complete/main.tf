# Example: Deploy Defender for Cloud with standard configuration

module "defender_for_cloud" {
  source = "../../"

  defender_plans = [
    { resource_type = "AppServices" },
    { resource_type = "Arm", subplan = "PerSubscription" },
    { resource_type = "KeyVaults", subplan = "PerKeyVault" },
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "VirtualMachines", subplan = "P2" },
    { resource_type = "CloudPosture" },
    { resource_type = "Containers" },
    { resource_type = "CosmosDbs" },
    { resource_type = "SqlServers" },
    { resource_type = "SqlServerVirtualMachines" },
    { resource_type = "OpenSourceRelationalDatabases" },
  ]

  security_contact = {
    name  = "Security Team"
    email = "security-team@opella.com"
    phone = "+1234567890"
  }

  security_center_settings = {
    WDATP = true
  }

  enable_mcsb_assignment          = true
  enable_vulnerability_assessment = true
}

output "enabled_plans" {
  value = module.defender_for_cloud.defender_plans
}
