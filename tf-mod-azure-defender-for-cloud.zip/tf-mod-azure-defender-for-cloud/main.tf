data "azurerm_subscription" "current" {}

#--------------------------------------------------------------
# Defender for Cloud - Subscription Pricing (Plans)
#--------------------------------------------------------------
resource "azurerm_security_center_subscription_pricing" "plans" {
  for_each = { for plan in var.defender_plans : plan.resource_type => plan }

  tier          = each.value.tier
  resource_type = each.value.resource_type
  subplan       = each.value.subplan

  dynamic "extension" {
    for_each = each.value.extensions != null ? each.value.extensions : []
    content {
      name                            = extension.value.name
      additional_extension_properties = extension.value.additional_extension_properties
    }
  }
}

#--------------------------------------------------------------
# Security Contact (optional)
#--------------------------------------------------------------
resource "azurerm_security_center_contact" "this" {
  count = var.security_contact != null ? 1 : 0

  email               = var.security_contact.email
  phone               = var.security_contact.phone
  name                = var.security_contact.name
  alert_notifications = var.alert_notifications_enabled
  alerts_to_admins    = var.alerts_to_admins_enabled
}
