data "azurerm_subscription" "current" {}

#--------------------------------------------------------------
# Defender for Cloud - Subscription Pricing (Plans)
#--------------------------------------------------------------
resource "azurerm_security_center_subscription_pricing" "plans" {
  for_each = { for plan in var.defender_plans : plan.resource_type => plan }

  tier          = each.value.tier
  resource_type = each.value.resource_type
  subplan       = each.value.subplan

  dynamic "extension" {
    for_each = each.value.extensions != null ? each.value.extensions : []
    content {
      name                            = extension.value.name
      additional_extension_properties = extension.value.additional_extension_properties
    }
  }
}

#--------------------------------------------------------------
# Security Contact (optional)
#--------------------------------------------------------------
resource "azurerm_security_center_contact" "this" {
  count = var.security_contact != null ? 1 : 0

  email               = var.security_contact.email
  phone               = var.security_contact.phone
  name                = var.security_contact.name
  alert_notifications = var.alert_notifications_enabled
  alerts_to_admins    = var.alerts_to_admins_enabled
}

#--------------------------------------------------------------
# Security Center Settings (MDE / MCAS / Sentinel)
#--------------------------------------------------------------
resource "azurerm_security_center_setting" "settings" {
  for_each = var.security_center_settings

  setting_name = each.key
  enabled      = each.value
}

#--------------------------------------------------------------
# Microsoft Cloud Security Benchmark (MCSB) Policy Assignment
#--------------------------------------------------------------
resource "azurerm_subscription_policy_assignment" "mcsb" {
  count = var.enable_mcsb_assignment ? 1 : 0

  name                 = var.mcsb_assignment_name
  display_name         = "Microsoft Cloud Security Benchmark"
  policy_definition_id = "/providers/Microsoft.Authorization/policySetDefinitions/1f3afdf9-d0c9-4c3d-847f-89da613e70a8"
  subscription_id      = data.azurerm_subscription.current.id
}

#--------------------------------------------------------------
# Log Analytics Workspace Integration (optional)
#--------------------------------------------------------------
resource "azurerm_security_center_workspace" "this" {
  count = var.log_analytics_workspace_id != null ? 1 : 0

  scope        = data.azurerm_subscription.current.id
  workspace_id = var.log_analytics_workspace_id
}
