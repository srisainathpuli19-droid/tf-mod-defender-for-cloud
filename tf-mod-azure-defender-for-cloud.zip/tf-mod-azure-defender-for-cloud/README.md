# tf-mod-azure-defender-for-cloud

Terraform module to configure **Microsoft Defender for Cloud** on an Azure subscription.

## Features

- Enable/disable individual Defender plans with subplans and extensions
- Configure security alert contacts
- Assign Microsoft Cloud Security Benchmark (MCSB) policy
- Enable Microsoft Defender for Endpoint (MDE) integration
- Configure vulnerability assessment provider
- Optional Log Analytics workspace integration

## Usage

### Minimal (enable defaults)

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=v1.0.0"

  security_contact = {
    email = "security-team@opella.com"
  }
}
```

### Full customization

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=v1.0.0"

  # Choose which Defender plans to enable
  defender_plans = [
    { resource_type = "AppServices" },
    { resource_type = "Arm", subplan = "PerSubscription" },
    { resource_type = "KeyVaults", subplan = "PerKeyVault" },
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "VirtualMachines", subplan = "P2" },
    { resource_type = "CloudPosture" },
    { resource_type = "Containers" },
    { resource_type = "CosmosDbs" },
    { resource_type = "SqlServers" },
    { resource_type = "SqlServerVirtualMachines" },
    { resource_type = "OpenSourceRelationalDatabases" },
  ]

  # Security contact for alerts
  security_contact = {
    name  = "Security Team"
    email = "security-team@opella.com"
    phone = "+1234567890"
  }

  alert_notifications_enabled = true
  alerts_to_admins_enabled    = true

  # Enable MDE (Defender for Endpoint) integration
  security_center_settings = {
    WDATP    = true
    MCAS     = false
    Sentinel = false
  }

  # MCSB policy assignment
  enable_mcsb_assignment = true

  # Vulnerability assessment
  enable_vulnerability_assessment    = true
  vulnerability_assessment_provider  = "MdeTvm"

  # Log Analytics workspace (optional)
  log_analytics_workspace_id = "/subscriptions/xxx/resourceGroups/xxx/providers/Microsoft.OperationalInsights/workspaces/xxx"
}
```

### Disable specific plans (Free tier)

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=v1.0.0"

  # Only enable specific plans
  defender_plans = [
    { resource_type = "VirtualMachines", subplan = "P1" },
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "Arm", subplan = "PerSubscription" },
  ]

  security_contact = {
    email = "security@opella.com"
  }

  # Skip MCSB if assigned elsewhere
  enable_mcsb_assignment = false
}
```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.5.0 |
| azurerm | >= 3.80.0 |
| azapi | >= 1.9.0 |

## Providers

| Name | Version |
|------|---------|
| azurerm | >= 3.80.0 |
| azapi | >= 1.9.0 |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|----------|
| defender_plans | List of Defender for Cloud plans to enable | list(object) | See variables.tf | no |
| security_contact | Security contact info (email required) | object | null | no |
| alert_notifications_enabled | Send alerts to security contact | bool | true | no |
| alerts_to_admins_enabled | Send alerts to subscription admins | bool | true | no |
| security_center_settings | Map of settings (WDATP, MCAS, Sentinel) | map(bool) | {WDATP=true} | no |
| enable_mcsb_assignment | Assign MCSB policy to subscription | bool | true | no |
| mcsb_assignment_name | Name for MCSB policy assignment | string | "mcsb" | no |
| enable_vulnerability_assessment | Enable VA provider setting | bool | true | no |
| vulnerability_assessment_provider | VA provider name | string | "MdeTvm" | no |
| log_analytics_workspace_id | Log Analytics workspace resource ID | string | null | no |

## Outputs

| Name | Description |
|------|-------------|
| defender_plans | Map of enabled plans with IDs |
| security_contact_id | Security contact resource ID |
| mcsb_assignment_id | MCSB policy assignment ID |
| subscription_id | Subscription where Defender is configured |

## References

- [Microsoft Defender for Cloud Terraform Sample](https://github.com/Azure/Microsoft-Defender-for-Cloud/tree/main/Terraform/Deploy%20Microsoft%20Defender%20for%20Cloud)
- [Claranet Defender Module](https://github.com/claranet/terraform-azurerm-defender-for-cloud)
- [azurerm_security_center_subscription_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing)
