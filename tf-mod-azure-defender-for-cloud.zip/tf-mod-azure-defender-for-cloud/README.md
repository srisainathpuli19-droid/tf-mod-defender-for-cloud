# Defender for Cloud module

Terraform module for enabling and configuring **Microsoft Defender for Cloud** on an Azure subscription, with support for plan selection, security contacts, MCSB policy assignment, MDE integration, vulnerability assessment, and Log Analytics workspace binding.

## Requirements

- Terraform `>= 1.5`
- `azurerm` provider `~> 4.0`
- `azapi` provider `~> 2.0`

## Usage

### Minimal — enable all recommended plans

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=<version>"

  security_contact = {
    email = "security-team@opella.com"
  }
}
```

By default, all recommended Defender plans are enabled at Standard tier with MCSB policy assigned and MDE (WDATP) integration active.

### Full customization

```hcl
module "defender_for_cloud" {
  source = "..."

  defender_plans = [
    { resource_type = "AppServices" },
    { resource_type = "Arm", subplan = "PerSubscription" },
    { resource_type = "KeyVaults", subplan = "PerKeyVault" },
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "VirtualMachines", subplan = "P2" },
    { resource_type = "CloudPosture" },
    { resource_type = "Containers" },
    { resource_type = "CosmosDbs" },
    { resource_type = "SqlServers" },
    { resource_type = "SqlServerVirtualMachines" },
    { resource_type = "OpenSourceRelationalDatabases" },
  ]

  security_contact = {
    name  = "Security Team"
    email = "security-team@opella.com"
    phone = "+1234567890"
  }

  alert_notifications_enabled = true
  alerts_to_admins_enabled    = true

  security_center_settings = {
    WDATP    = true
    MCAS     = false
    Sentinel = false
  }

  enable_mcsb_assignment          = true
  enable_vulnerability_assessment = true

  log_analytics_workspace_id = "/subscriptions/xxx/resourceGroups/xxx/providers/Microsoft.OperationalInsights/workspaces/xxx"
}
```

### Selective plans only

```hcl
module "defender_for_cloud" {
  source = "..."

  defender_plans = [
    { resource_type = "VirtualMachines", subplan = "P1" },
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "Arm", subplan = "PerSubscription" },
  ]

  security_contact = {
    email = "security@opella.com"
  }

  enable_mcsb_assignment = false
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| `defender_plans` | List of Defender plans to enable (see below) | `list(object)` | all recommended plans | no |
| `security_contact` | Security contact for alerts (see below) | `object` | `null` | no |
| `alert_notifications_enabled` | Send alert notifications to security contact | `bool` | `true` | no |
| `alerts_to_admins_enabled` | Send alert notifications to subscription admins | `bool` | `true` | no |
| `security_center_settings` | Map of settings to enable (WDATP, MCAS, Sentinel) | `map(bool)` | `{ WDATP = true }` | no |
| `enable_mcsb_assignment` | Assign Microsoft Cloud Security Benchmark policy | `bool` | `true` | no |
| `mcsb_assignment_name` | Name for the MCSB policy assignment | `string` | `"mcsb"` | no |
| `enable_vulnerability_assessment` | Enable vulnerability assessment provider | `bool` | `true` | no |
| `vulnerability_assessment_provider` | VA provider name | `string` | `"MdeTvm"` | no |
| `log_analytics_workspace_id` | Log Analytics workspace resource ID | `string` | `null` | no |

### `defender_plans` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `resource_type` | `string` | — | Azure resource type (AppServices, Arm, VirtualMachines, etc.) |
| `tier` | `string` | `"Standard"` | Standard or Free |
| `subplan` | `string` | `null` | Subplan (P1, P2, PerSubscription, PerKeyVault, DefenderForStorageV2) |
| `extensions` | `list(object)` | `null` | Optional extensions for the plan |

### `security_contact` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `email` | `string` | — | Email address for security alerts |
| `name` | `string` | `null` | Contact name |
| `phone` | `string` | `null` | Phone number |

## Outputs

| Name | Description | Sensitive |
|------|-------------|-----------|
| `defender_plans` | Map of enabled plans with resource IDs | no |
| `security_contact_id` | Security contact resource ID | no |
| `mcsb_assignment_id` | MCSB policy assignment resource ID | no |
| `subscription_id` | Subscription ID where Defender is configured | no |

## References

- [Microsoft Defender for Cloud Terraform Sample](https://github.com/Azure/Microsoft-Defender-for-Cloud/tree/main/Terraform/Deploy%20Microsoft%20Defender%20for%20Cloud)
- [Claranet Defender Module](https://github.com/claranet/terraform-azurerm-defender-for-cloud)
- [azurerm_security_center_subscription_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing)

<!-- BEGIN_TF_DOCS -->
<!-- END_TF_DOCS -->
