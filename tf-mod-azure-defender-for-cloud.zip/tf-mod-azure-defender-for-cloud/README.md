# Defender for Cloud module

Terraform module for enabling **Microsoft Defender for Cloud** plans on an Azure subscription. This module supports a restricted set of resource types only.

## Supported Resource Types

| Defender Plan | `resource_type` value | Common Subplan |
|---------------|----------------------|----------------|
| Servers | `VirtualMachines` | `P1`, `P2` |
| App Service | `AppServices` | — |
| Azure SQL Databases | `SqlServers` | — |
| SQL Servers on machines | `SqlServerVirtualMachines` | — |
| Open-source relational databases | `OpenSourceRelationalDatabases` | — |
| Azure Cosmos DB | `CosmosDbs` | — |
| Storage | `StorageAccounts` | `DefenderForStorageV2`, `PerStorageAccount`, `PerTransaction` |
| Containers | `Containers` | — |
| Key Vault | `KeyVaults` | `PerKeyVault` |
| Resource Manager | `Arm` | `PerSubscription` |
| APIs | `Api` | — |

## Requirements

- Terraform `>= 1.5`
- `azurerm` provider `~> 4.0`

## Usage

### Minimal — enable all supported plans with defaults

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=<version>"

  security_contact = {
    email = "security-team@opella.com"
  }
}
```

By default, all supported plans are enabled at Standard tier with recommended subplans.

### Selective plans only

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=<version>"

  defender_plans = [
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "KeyVaults", subplan = "PerKeyVault" },
    { resource_type = "Containers" },
  ]

  security_contact = {
    email = "security@opella.com"
  }
}
```

### With extensions (e.g., malware scanning for Storage)

```hcl
module "defender_for_cloud" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-defender-for-cloud.git?ref=<version>"

  defender_plans = [
    {
      resource_type = "StorageAccounts"
      subplan       = "DefenderForStorageV2"
      extensions = [
        {
          name = "OnUploadMalwareScanning"
          additional_extension_properties = {
            CapGBPerMonthPerStorageAccount = "5000"
          }
        },
        { name = "SensitiveDataDiscovery" },
      ]
    },
    { resource_type = "VirtualMachines", subplan = "P2" },
    { resource_type = "SqlServers" },
    { resource_type = "Arm", subplan = "PerSubscription" },
  ]

  security_contact = {
    name  = "Security Team"
    email = "security-team@opella.com"
    phone = "+1234567890"
  }
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| `defender_plans` | List of Defender plans to enable (see below) | `list(object)` | All supported plans | no |
| `security_contact` | Security contact for alerts (see below) | `object` | `null` | no |
| `alert_notifications_enabled` | Send alert notifications to security contact | `bool` | `true` | no |
| `alerts_to_admins_enabled` | Send alert notifications to subscription admins | `bool` | `true` | no |

### `defender_plans` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `resource_type` | `string` | — | One of the supported resource types (see table above) |
| `tier` | `string` | `"Standard"` | `Standard` or `Free` |
| `subplan` | `string` | `null` | Plan-specific subplan |
| `extensions` | `list(object)` | `null` | Optional extensions for the plan |

### `extensions` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `name` | `string` | — | Extension name (e.g., OnUploadMalwareScanning, SensitiveDataDiscovery) |
| `additional_extension_properties` | `map(string)` | `null` | Extra properties for the extension |

### `security_contact` object

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `email` | `string` | — | Email address for security alerts |
| `name` | `string` | `null` | Contact name |
| `phone` | `string` | `null` | Phone number |

## Outputs

| Name | Description | Sensitive |
|------|-------------|-----------|
| `defender_plans` | Map of enabled plans with resource IDs, tier, and subplan | no |
| `security_contact_id` | Security contact resource ID | no |
| `subscription_id` | Subscription ID where Defender is configured | no |

## References

- [Microsoft Defender for Cloud overview](https://learn.microsoft.com/en-us/azure/defender-for-cloud/defender-for-cloud-introduction)
- [azurerm_security_center_subscription_pricing](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing)

<!-- BEGIN_TF_DOCS -->
<!-- END_TF_DOCS -->
