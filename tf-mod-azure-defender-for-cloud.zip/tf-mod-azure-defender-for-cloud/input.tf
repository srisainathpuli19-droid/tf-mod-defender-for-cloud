#--------------------------------------------------------------
# Defender Plans Configuration
#--------------------------------------------------------------
variable "defender_plans" {
  description = <<-EOT
    List of Defender for Cloud plans to enable. Each plan requires:
    - resource_type: The Azure resource type (e.g., "AppServices", "Arm", "VirtualMachines", "StorageAccounts", etc.)
    - tier: "Standard" or "Free" (default: "Standard")
    - subplan: Optional subplan (e.g., "P1", "P2", "PerSubscription", "PerKeyVault", "DefenderForStorageV2")
    - extensions: Optional list of extensions for the plan

    See: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/security_center_subscription_pricing
  EOT
  type = list(object({
    resource_type = string
    tier          = optional(string, "Standard")
    subplan       = optional(string, null)
    extensions = optional(list(object({
      name                            = string
      additional_extension_properties = optional(map(string), null)
    })), null)
  }))
  default = [
    { resource_type = "AppServices" },
    {
      resource_type = "Arm"
      subplan       = "PerSubscription"
    },
    {
      resource_type = "KeyVaults"
      subplan       = "PerKeyVault"
    },
    {
      resource_type = "StorageAccounts"
      subplan       = "DefenderForStorageV2"
    },
    {
      resource_type = "VirtualMachines"
      subplan       = "P2"
    },
    { resource_type = "CloudPosture" },
    { resource_type = "Containers" },
    { resource_type = "CosmosDbs" },
    { resource_type = "OpenSourceRelationalDatabases" },
    { resource_type = "SqlServers" },
    { resource_type = "SqlServerVirtualMachines" },
  ]
}

#--------------------------------------------------------------
# Security Contact
#--------------------------------------------------------------
variable "security_contact" {
  description = "Security contact information for Defender for Cloud alerts. Set to null to skip."
  type = object({
    name  = optional(string, null)
    email = string
    phone = optional(string, null)
  })
  default = null
}

variable "alert_notifications_enabled" {
  description = "Whether to send security alert notifications to the security contact."
  type        = bool
  default     = true
}

variable "alerts_to_admins_enabled" {
  description = "Whether to send security alert notifications to subscription admins (Owners)."
  type        = bool
  default     = true
}

#--------------------------------------------------------------
# Security Center Settings
#--------------------------------------------------------------
variable "security_center_settings" {
  description = <<-EOT
    Map of security center settings to enable/disable.
    Supported keys: "WDATP" (Microsoft Defender for Endpoint), "MCAS" (Microsoft Cloud App Security), "Sentinel".
  EOT
  type        = map(bool)
  default = {
    WDATP = true
  }
}

#--------------------------------------------------------------
# MCSB Policy Assignment
#--------------------------------------------------------------
variable "enable_mcsb_assignment" {
  description = "Whether to assign the Microsoft Cloud Security Benchmark (MCSB) policy initiative to the subscription."
  type        = bool
  default     = true
}

variable "mcsb_assignment_name" {
  description = "The name for the MCSB policy assignment resource."
  type        = string
  default     = "mcsb"
}

#--------------------------------------------------------------
# Vulnerability Assessment
#--------------------------------------------------------------
variable "enable_vulnerability_assessment" {
  description = "Whether to enable the vulnerability assessment provider setting for Defender for Servers."
  type        = bool
  default     = true
}

variable "vulnerability_assessment_provider" {
  description = "The vulnerability assessment provider to use. Options: 'MdeTvm' (Microsoft Defender Vulnerability Management)."
  type        = string
  default     = "MdeTvm"

  validation {
    condition     = contains(["MdeTvm"], var.vulnerability_assessment_provider)
    error_message = "Valid options are MdeTvm."
  }
}

#--------------------------------------------------------------
# Log Analytics Workspace
#--------------------------------------------------------------
variable "log_analytics_workspace_id" {
  description = "The full resource ID of the Log Analytics workspace for Defender for Cloud. Set to null to skip."
  type        = string
  default     = null
}
