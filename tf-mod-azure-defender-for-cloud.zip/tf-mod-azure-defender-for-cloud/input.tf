#--------------------------------------------------------------
# Defender Plans Configuration
#--------------------------------------------------------------
variable "defender_plans" {
  description = <<-EOT
    List of Defender for Cloud plans to enable. Only the following resource types are supported:
    - VirtualMachines (Servers)
    - AppServices (App Service)
    - SqlServers (Azure SQL Databases)
    - SqlServerVirtualMachines (SQL Servers on machines)
    - OpenSourceRelationalDatabases (Open-source relational databases)
    - CosmosDbs (Azure Cosmos DB)
    - StorageAccounts (Storage)
    - Containers
    - KeyVaults (Key Vault)
    - Arm (Resource Manager)
    - Api (APIs)

    Each plan accepts:
    - resource_type: One of the supported types above
    - tier: "Standard" or "Free" (default: "Standard")
    - subplan: Optional subplan (e.g., "P1", "P2", "DefenderForStorageV2", "PerKeyVault", "PerSubscription")
    - extensions: Optional list of extensions
  EOT
  type = list(object({
    resource_type = string
    tier          = optional(string, "Standard")
    subplan       = optional(string, null)
    extensions = optional(list(object({
      name                            = string
      additional_extension_properties = optional(map(string), null)
    })), null)
  }))
  nullable = false

  default = [
    { resource_type = "VirtualMachines", subplan = "P2" },
    { resource_type = "AppServices" },
    { resource_type = "SqlServers" },
    { resource_type = "SqlServerVirtualMachines" },
    { resource_type = "OpenSourceRelationalDatabases" },
    { resource_type = "CosmosDbs" },
    { resource_type = "StorageAccounts", subplan = "DefenderForStorageV2" },
    { resource_type = "Containers" },
    { resource_type = "KeyVaults", subplan = "PerKeyVault" },
    { resource_type = "Arm", subplan = "PerSubscription" },
    { resource_type = "Api" },
  ]

  validation {
    condition = alltrue([
      for plan in var.defender_plans : contains([
        "VirtualMachines",
        "AppServices",
        "SqlServers",
        "SqlServerVirtualMachines",
        "OpenSourceRelationalDatabases",
        "CosmosDbs",
        "StorageAccounts",
        "Containers",
        "KeyVaults",
        "Arm",
        "Api",
      ], plan.resource_type)
    ])
    error_message = "Only the following resource_type values are supported: VirtualMachines, AppServices, SqlServers, SqlServerVirtualMachines, OpenSourceRelationalDatabases, CosmosDbs, StorageAccounts, Containers, KeyVaults, Arm, Api."
  }
}

#--------------------------------------------------------------
# Security Contact
#--------------------------------------------------------------
variable "security_contact" {
  description = "Security contact information for Defender for Cloud alerts. Set to null to skip."
  type = object({
    name  = optional(string, null)
    email = string
    phone = optional(string, null)
  })
  default = null
}

variable "alert_notifications_enabled" {
  description = "Whether to send security alert notifications to the security contact."
  type        = bool
  default     = true
}

variable "alerts_to_admins_enabled" {
  description = "Whether to send security alert notifications to subscription admins (Owners)."
  type        = bool
  default     = true
}
