#--------------------------------------------------------------
# Defender Plans — Subscription-Level
#--------------------------------------------------------------
variable "defender_plans" {
  description = <<-EOT
    List of Defender for Cloud plans to enable at the subscription level.
    Supported resource types:
    - VirtualMachines         (Servers)
    - AppServices             (App Service)
    - SqlServers              (Azure SQL Databases)
    - SqlServerVirtualMachines (SQL Servers on machines)
    - OpenSourceRelationalDatabases (Open-source relational databases)
    - CosmosDbs               (Azure Cosmos DB)
    - StorageAccounts         (Storage)
    - Containers              (Containers)
    - ContainerRegistry       (Container Registry)
    - KubernetesService       (Kubernetes / AKS)
    - KeyVaults               (Key Vault)
    - Arm                     (Resource Manager)
    - Api                     (APIs)
    - AI                      (Azure AI Services)
    - Dns                     (DNS)
    - CloudPosture            (Cloud Security Posture Management / CSPM)

    Each plan accepts:
    - resource_type: One of the supported types above
    - tier: "Standard" or "Free" (default: "Standard")
    - subplan: Optional subplan (e.g., "P1", "P2", "DefenderForStorageV2", "PerKeyVault", "PerSubscription")
    - extensions: Optional list of extensions
  EOT
  type = list(object({
    resource_type = string
    tier          = optional(string, "Standard")
    subplan       = optional(string, null)
    extensions = optional(list(object({
      name                            = string
      additional_extension_properties = optional(map(string), null)
    })), null)
  }))
  default  = []
  nullable = false

  validation {
    condition = alltrue([
      for plan in var.defender_plans : contains([
        "VirtualMachines",
        "AppServices",
        "SqlServers",
        "SqlServerVirtualMachines",
        "OpenSourceRelationalDatabases",
        "CosmosDbs",
        "StorageAccounts",
        "Containers",
        "ContainerRegistry",
        "KubernetesService",
        "KeyVaults",
        "Arm",
        "Api",
        "AI",
        "Dns",
        "CloudPosture",
      ], plan.resource_type)
    ])
    error_message = "Only the following resource_type values are supported: VirtualMachines, AppServices, SqlServers, SqlServerVirtualMachines, OpenSourceRelationalDatabases, CosmosDbs, StorageAccounts, Containers, ContainerRegistry, KubernetesService, KeyVaults, Arm, Api, AI, Dns, CloudPosture."
  }
}

#--------------------------------------------------------------
# Security Contact
#--------------------------------------------------------------
variable "security_contact" {
  description = "Security contact information for Defender for Cloud alerts. Set to null to skip."
  type = object({
    name  = optional(string, null)
    email = string
    phone = optional(string, null)
  })
  default = null
}

variable "alert_notifications_enabled" {
  description = "Whether to send security alert notifications to the security contact."
  type        = bool
  default     = true
}

variable "alerts_to_admins_enabled" {
  description = "Whether to send security alert notifications to subscription admins (Owners)."
  type        = bool
  default     = true
}

#--------------------------------------------------------------
# Security Center Settings
#--------------------------------------------------------------
variable "security_center_settings" {
  description = <<-EOT
    Map of security center settings to enable/disable.
    Supported keys:
    - "WDATP" — Microsoft Defender for Endpoint (enables built-in VA for Servers)
    - "MCAS" — Microsoft Defender for Cloud Apps
    - "Sentinel" — Microsoft Sentinel integration
  EOT
  type        = map(bool)
  default     = {}
}

#--------------------------------------------------------------
# MCSB Policy Assignment
#--------------------------------------------------------------
variable "enable_mcsb_assignment" {
  description = "Whether to assign the Microsoft Cloud Security Benchmark (MCSB) policy initiative to the subscription."
  type        = bool
  default     = false
}

variable "mcsb_assignment_name" {
  description = "The name for the MCSB policy assignment resource."
  type        = string
  default     = "mcsb"
}

#--------------------------------------------------------------
# Log Analytics Workspace
#--------------------------------------------------------------
variable "log_analytics_workspace_id" {
  description = "The full resource ID of the Log Analytics workspace for Defender for Cloud data. Set to null to skip."
  type        = string
  default     = null
}

#--------------------------------------------------------------
# Defender for Storage — Per-Resource
#--------------------------------------------------------------
variable "storage_accounts" {
  description = <<-EOT
    List of storage accounts to enable Defender for Storage on individually.
    Each entry targets a specific storage account by its resource ID.

    Arguments:
    - storage_account_id: Full Azure resource ID of the storage account
    - override_subscription_settings_enabled: Override subscription-level Defender settings (default: true)
    - malware_scanning_on_upload_enabled: Enable on-upload malware scanning (default: true)
    - malware_scanning_on_upload_cap_gb_per_month: Max GB scanned per month, -1 for unlimited (default: -1)
    - sensitive_data_discovery_enabled: Enable sensitive data discovery (default: true)
    - scan_results_event_grid_topic_id: Event Grid topic for scan results (default: null)
  EOT
  type = list(object({
    storage_account_id                          = string
    override_subscription_settings_enabled      = optional(bool, true)
    malware_scanning_on_upload_enabled          = optional(bool, true)
    malware_scanning_on_upload_cap_gb_per_month = optional(number, -1)
    sensitive_data_discovery_enabled            = optional(bool, true)
    scan_results_event_grid_topic_id            = optional(string, null)
  }))
  default  = []
  nullable = false
}

#--------------------------------------------------------------
# Advanced Threat Protection — Per-Resource (Key Vaults, Cosmos DB, etc.)
#--------------------------------------------------------------
variable "advanced_threat_protection_resource_ids" {
  description = <<-EOT
    List of Azure resource IDs to enable Advanced Threat Protection on.
    Supported resource types: Key Vaults, Cosmos DB accounts, Storage Accounts (legacy).
    Use this for resources that do not have a dedicated per-resource Defender resource.
  EOT
  type        = list(string)
  default     = []
  nullable    = false
}

#--------------------------------------------------------------
# Security Center Automation Rules (Workflow Automation & Continuous Export)
#--------------------------------------------------------------
variable "automation_rules" {
  description = <<-EOT
    List of Security Center automation rules for workflow automation and continuous export.
    Automation rules can export findings to Event Hubs and Log Analytics workspaces.

    Arguments:
    - name: Name of the automation rule (must be unique within subscription)
    - enabled: Whether the rule is enabled (default: true)
    - description: Optional description of the rule
    - scopes: Optional list of scopes (defaults to current subscription)
    - event_hubs_resource_id: Optional Event Hub resource ID for exporting findings
    - log_analytics_workspace_id: Optional Log Analytics workspace ID for exporting findings
  EOT
  type = list(object({
    name                       = string
    enabled                    = optional(bool, true)
    description                = optional(string, null)
    scopes                     = optional(list(string), null)
    event_hubs_resource_id     = optional(string, null)
    log_analytics_workspace_id = optional(string, null)
  }))
  default  = []
  nullable = false
}
