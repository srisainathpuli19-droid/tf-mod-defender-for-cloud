environment     = "prod"
location        = "swedencentral"
region_name     = "eu01"
application_id  = "APM0092087"
app_category    = "gold"
contextual_name = "epam-tools"
vm_sku          = "Standard_D8s_v5"
os_disk_type    = "Premium_LRS"
os_disk_size    = "128"
patch_wave_1    = "0"
patch_wave_2    = "1"

# ================================================
# Foundry configuration
# ================================================
foundry_sku                    = "S0"
foundry_disable_local_auth     = false
foundry_public_network_access  = "Disabled"

# Legacy variables (required by module but unused in its main.tf)
foundry_deployment_name = "gpt-4o"
foundry_model_name      = "gpt-4o"
foundry_model_version   = "2024-11-20"
foundry_model_capacity  = "1"

# Knowledge storage
foundry_knowledge_storage_name = "steu01prodepamfoundry01"

# Connections
# TODO: Replace with actual Cosmos DB account resource ID
foundry_cosmos_account_id      = "" # /subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.DocumentDB/databaseAccounts/<name>
foundry_connection_resource_id = "" # Same Cosmos DB resource ID as above
foundry_connection_display_name         = "cosmos-connection"
foundry_connection_display_name_storage = "knowledge-storage"
# TODO: Replace with actual blob endpoint of knowledge storage
foundry_connection_target = "https://steu01prodepamfoundry01.blob.core.windows.net/"

# Projects
foundry_projects = {
  default = {
    display_name = "EPAM Foundry Production"
    description  = "Production AI project for EPAM tools"
    environment  = "prod"
    common_tags  = {}
  }
}

# Model deployments
foundry_model_deployments = {
  gpt4o = {
    model_name    = "gpt-4o"
    model_version = "2024-11-20"
    model_format  = "OpenAI"
    sku_name      = "GlobalStandard"
    capacity      = 1
    enabled       = true
  }
}