# General variables

variable "subscription_id" {
  type        = string
  description = "The Azure subscription ID where the Azure Resources will be deployed."

  # Value is sourced from the ARM_SUBSCRIPTION_ID in CI environment
  default = null
}

variable "environment" {
  type        = string
  description = <<EOT
Represent a final environment (dev, int, prd, …).
Contrary to `environment_type`, this component cannot accept value that "group" environment together.
However, an environment of "mut" is accepted for resources shared across multiple environments.

To avoid confusion with environment type `prod`, `prd` should be used to design the specific `production` environment.
EOT

  validation {
    condition = contains(
      [
        "",
        "prod",
        "nonprod",
        "sand",
        "test",
        "dev",
        "stg",
        "trn",
        "uat",
      ],
    var.environment)

    error_message = "The `environment` must be one of: `prod`, `nonprod`, `sand`, `test`, `dev`, `stg`, `trn`, `uat`"
  }
}

variable "region_name" {
  type        = string
  description = <<EOT
Region where the resource is deployed.
Region are based on a specific naming convention and not on the Azure names.

Example: eu01, us01, ap01, glob (global), etc.
EOT

}

variable "location" {
  type        = string
  description = "Location where the resources will be deployed, e.g., swedencentral, westeurope"
}

variable "contextual_name" {
  type        = string
  description = "contextual name"
}

variable "application_id" {
  type        = string
  description = "application id, eg: APM0090733"
}

variable "app_category" {
  type        = string
  description = "app category, eg:bronze, gold, platinum"
}

variable "vm_sku" {
  type        = string
  default     = "Standard_D8s_v5"
  description = "VM SKU size"
}

variable "os_disk_type" {
  type        = string
  description = "virtual machine os disk type"
}

variable "os_disk_size" {
  type        = string
  description = "os disk size for vm"
}

variable "patch_wave_1" {
  type        = number
  description = "tag value 0 means patch_wave = 1"
}

variable "patch_wave_2" {
  type        = number
  description = "tag value 1 means patch_wave = 2"
}

# ================================================
# Foundry variables
# ================================================

variable "foundry_sku" {
  type        = string
  default     = "S0"
  description = "SKU for the Azure AI Foundry (S0 only for AIServices)"
}

variable "foundry_disable_local_auth" {
  type        = bool
  default     = false
  description = "Disable local authentication on the AI Foundry"
}

variable "foundry_public_network_access" {
  type        = string
  default     = "Disabled"
  description = "Public network access for the AI Foundry (Enabled/Disabled)"
}

variable "foundry_projects" {
  type = map(object({
    display_name = string
    description  = string
    environment  = optional(string, "dev")
    common_tags  = optional(map(string), {})
  }))
  default     = {}
  description = "Map of projects to create in the AI Foundry"
}

variable "foundry_model_deployments" {
  type = map(object({
    model_name    = string
    model_version = string
    model_format  = optional(string, "OpenAI")
    sku_name      = optional(string, "GlobalStandard")
    capacity      = optional(number, 1)
    enabled       = optional(bool, true)
  }))
  default     = {}
  description = "Map of model deployments to create in the AI Foundry"
}

# Legacy variables - required by the module interface but not actively used
# in its main.tf (module uses model_deployments map instead)
variable "foundry_deployment_name" {
  type        = string
  description = "Legacy: Name for model deployment (unused by module, kept for interface compatibility)"
}

variable "foundry_model_name" {
  type        = string
  description = "Legacy: Model name (unused by module, kept for interface compatibility)"
}

variable "foundry_model_version" {
  type        = string
  description = "Legacy: Model version (unused by module, kept for interface compatibility)"
}

variable "foundry_model_capacity" {
  type        = string
  description = "Legacy: Capacity (unused by module, kept for interface compatibility)"
}

# Knowledge storage & connections
variable "foundry_knowledge_storage_name" {
  type        = string
  description = "Name of the storage account for knowledge store (3-24 chars, lowercase alphanumeric only)"
}

variable "foundry_cosmos_account_id" {
  type        = string
  description = "Cosmos DB account ID (required by module interface, appears unused — use foundry_connection_resource_id)"
}

variable "foundry_connection_resource_id" {
  type        = string
  description = "Resource ID for the Cosmos DB account (used in cosmos_connection metadata)"
}

variable "foundry_connection_display_name" {
  type        = string
  description = "Display name for the Cosmos connection"
}

variable "foundry_connection_display_name_storage" {
  type        = string
  description = "Display name for the storage connection"
}

variable "foundry_connection_target" {
  type        = string
  description = "Target blob endpoint for the knowledge storage connection (e.g., https://<name>.blob.core.windows.net/)"
}


