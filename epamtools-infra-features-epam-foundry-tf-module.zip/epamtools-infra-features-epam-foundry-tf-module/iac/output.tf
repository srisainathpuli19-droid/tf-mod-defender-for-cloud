output "foundry_name" {
  value       = module.ai_foundry.foundry_name
  description = "AI Foundry name"
}

output "foundry_id" {
  value       = module.ai_foundry.foundry_id
  description = "AI Foundry ID"
}

output "foundry_endpoint" {
  value       = module.ai_foundry.foundry_endpoint
  description = "AI Foundry endpoint"
}

output "foundry_project_names" {
  value       = module.ai_foundry.project_names
  description = "Map of created project names"
}

output "foundry_project_ids" {
  value       = module.ai_foundry.project_ids
  description = "Map of created project IDs"
}

output "foundry_model_deployment_names" {
  value       = module.ai_foundry.model_deployment_names
  description = "Map of model deployment names"
}

output "foundry_model_endpoints" {
  value       = module.ai_foundry.model_endpoints
  description = "Map of model endpoints"
}

output "foundry_principal_id" {
  value       = module.ai_foundry.foundry_principal_id
  description = "Managed Identity principal ID of the AI Foundry"
}
