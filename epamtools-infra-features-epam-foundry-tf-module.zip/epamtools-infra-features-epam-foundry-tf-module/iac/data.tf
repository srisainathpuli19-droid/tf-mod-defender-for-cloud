data "azurerm_virtual_network" "epam_tools" {
  name                = "vnet-${var.region_name}-${var.environment}-epam-tools-01"
  resource_group_name = "rg-${var.region_name}-${var.environment}-core"
}

data "azurerm_recovery_services_vault" "epam_vault" {
  name                = "rsv-${var.region_name}-${var.environment}-epam-tools-01"
  resource_group_name = "rg-${var.region_name}-${var.environment}-core"
}
data "azurerm_backup_policy_vm" "epam_policy" {
  name                = "bkpol-gold"
  recovery_vault_name = data.azurerm_recovery_services_vault.epam_vault.name
  resource_group_name = data.azurerm_recovery_services_vault.epam_vault.resource_group_name
}