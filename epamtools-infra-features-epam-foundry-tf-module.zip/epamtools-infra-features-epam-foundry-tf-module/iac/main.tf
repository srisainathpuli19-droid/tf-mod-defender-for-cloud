data "azurerm_client_config" "current" {}

module "naming_convention" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-naming-convention?ref=v7"

  environment     = var.environment
  region          = var.region_name
  contextual_name = var.contextual_name
}

module "tagging_convention" {
  source         = "git::https://github.com/opella-innersource/tf-mod-azure-tagging-convention?ref=v2.2.0"
  environment    = var.environment
  region         = var.region_name
  application_id = var.application_id
  app_category   = var.app_category
}
