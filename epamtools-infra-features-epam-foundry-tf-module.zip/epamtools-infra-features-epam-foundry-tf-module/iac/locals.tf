locals {
  resource_groups = toset([
    "migvisor",
    "foundry"
  ])
}

locals {
  key_vaults = {
    passwords = {
      name = "migvisor"
    }
  }
}

locals {
  linux_images = {
    ubuntu_2204 = {
      publisher = "Canonical"
      offer     = "0001-com-ubuntu-server-jammy"
      sku       = "22_04-lts-gen2"
      version   = "latest"
    }
  }
}

locals {
  linux_vms = {
    OSPL10W855I = {
      sku             = var.vm_sku
      image_key       = "ubuntu_2204"
      os_disk_type    = var.os_disk_type
      os_disk_size_gb = var.os_disk_size
      data_disks      = {}
      tag_index       = var.patch_wave_1
    }
    OSPL10T539W = {
      sku             = var.vm_sku
      image_key       = "ubuntu_2204"
      os_disk_type    = var.os_disk_type
      os_disk_size_gb = var.os_disk_size
      data_disks      = {}
      tag_index       = var.patch_wave_1
    }
    OSPL10B746W = {
      sku             = var.vm_sku
      image_key       = "ubuntu_2204"
      os_disk_type    = var.os_disk_type
      os_disk_size_gb = var.os_disk_size
      data_disks = {
        "data-01" = {
          lun     = 0
          size_gb = "640"
          caching = "ReadWrite"
          type    = "StandardSSD_LRS"
        }
      }
      tag_index = var.patch_wave_1
    }
  }
}

locals {
  virtual_network_address_space      = data.azurerm_virtual_network.epam_tools.address_space[0]
  virtual_network_address_space_size = tonumber(split("/", local.virtual_network_address_space)[1])

  # BEWARE order matter, re-ordering will remove/re-add subnets
  subnets = [
    {
      name = "01"
      sizes = {
        default = 28
      }
    }
  ]

  subnets_for_current_env = [
    for subnet in local.subnets :
    merge(subnet, {
      size = lookup(subnet.sizes, var.environment, subnet.sizes["default"])
    })
    if !(contains(try(subnet.exclude_in, []), var.environment))
  ]

  subnets_map = {
    for subnet in local.subnets_for_current_env :
    subnet.name => merge(subnet, {
      address_prefix = module.subnets_blocks.network_cidr_blocks[subnet.name]
    })
  }
}