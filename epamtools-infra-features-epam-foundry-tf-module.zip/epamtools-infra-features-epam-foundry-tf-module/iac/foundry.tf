# Azure AI Foundry Service
# Module source: https://github.com/opella-innersource/tf-mod-azure-foundry

module "ai_foundry" {
  source = "git::https://github.com/opella-innersource/tf-mod-azure-foundry?ref=main"

  foundry_name            = "cog-${var.region_name}-${var.environment}-${var.contextual_name}-foundry-01"
  location                = var.location
  resource_group_id       = azurerm_resource_group.resource_groups["foundry"].id
  resource_group_name     = azurerm_resource_group.resource_groups["foundry"].name
  resource_group_location = var.location
  foundry_sku             = var.foundry_sku
  disable_local_auth      = var.foundry_disable_local_auth
  public_network_access   = var.foundry_public_network_access
  environment             = var.environment

  # Projects
  projects = var.foundry_projects

  # Model deployments
  model_deployments = var.foundry_model_deployments
  name              = var.foundry_deployment_name
  sku               = var.foundry_sku
  model_name        = var.foundry_model_name
  model_version     = var.foundry_model_version
  capacity          = var.foundry_model_capacity

  # Knowledge storage & connections
  knowledge_storage_name = var.foundry_knowledge_storage_name
  cosmos_account_id      = var.foundry_cosmos_account_id
  resource_id            = var.foundry_connection_resource_id
  display_name           = var.foundry_connection_display_name
  display_name_storage   = var.foundry_connection_display_name_storage
  target                 = var.foundry_connection_target

  tags = module.tagging_convention.tags
}
